import { useState } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import AIChat from "./pages/AIChat";
import AIProfile from "./pages/AIProfile";
import AIDiagnosis from "./pages/AIDiagnosis";
import AIAnalysis from "./pages/AIAnalysis";
import TweaksCenter from "./pages/TweaksCenter";
import Benchmark from "./pages/Benchmark";
import PlaceholderPage from "./pages/PlaceholderPage";
import GlobalStyles from "./components/GlobalStyles";
import useSystemMetrics from "./hooks/useSystemMetrics";
import { TWEAKS_DATA } from "./utils/tweaksData";

export default function App() {
  const [activeNav, setActiveNav] = useState("dashboard");
  const [tweaks, setTweaks] = useState(
    TWEAKS_DATA.map((t, i) => ({ ...t, applied: i < 3 }))
  );
  const [gameMode, setGameMode] = useState(false);
  const { cpu, ram, gpu } = useSystemMetrics();

  const appliedCount = tweaks.filter((t) => t.applied).length;

  const toggleTweak = (index) => {
    setTweaks((prev) =>
      prev.map((t, i) => (i === index ? { ...t, applied: !t.applied } : t))
    );
  };

  const applyAll = () => {
    setTweaks((prev) => prev.map((t) => ({ ...t, applied: true })));
  };

  const pageProps = {
    activeNav,
    tweaks, toggleTweak, applyAll, appliedCount,
    gameMode, setGameMode,
    cpu, ram, gpu,
  };

  const renderPage = () => {
    switch (activeNav) {
      case "dashboard":   return <Dashboard {...pageProps} />;
      case "ai-chat":     return <AIChat />;
      case "ai-profile":  return <AIProfile />;
      case "ai-diagnosis":return <AIDiagnosis />;
      case "ai-analysis": return <AIAnalysis />;
      case "tweaks":      return <TweaksCenter tweaks={tweaks} toggleTweak={toggleTweak} applyAll={applyAll} appliedCount={appliedCount} total={tweaks.length} />;
      case "benchmark":   return <Benchmark />;
      case "network":     return <PlaceholderPage icon="📡" title="NETWORK OPTIMIZER" version="1.1" />;
      case "cleaner":     return <PlaceholderPage icon="🧹" title="SYSTEM CLEANER" version="1.1" />;
      case "settings":    return <PlaceholderPage icon="⚙️" title="SETTINGS" version="1.1" />;
      default:            return <Dashboard {...pageProps} />;
    }
  };

  return (
    <>
      <GlobalStyles />
      <div style={{ display: "flex", height: "100vh", background: "#060d14", overflow: "hidden" }}>
        <Sidebar
          activeNav={activeNav}
          setActiveNav={setActiveNav}
          cpu={cpu} ram={ram} gpu={gpu}
          appliedCount={appliedCount}
        />
        <main style={{ flex: 1, overflowY: "auto", padding: 24, position: "relative", zIndex: 5 }}>
          {renderPage()}
        </main>
      </div>
    </>
  );
}
