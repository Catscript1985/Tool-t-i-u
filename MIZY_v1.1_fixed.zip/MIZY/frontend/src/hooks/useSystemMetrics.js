import { useState, useEffect } from "react";

// Simulates live system metrics (in production, fetches from Python backend)
export default function useSystemMetrics() {
  const [cpu, setCpu] = useState(47);
  const [ram, setRam] = useState(62);
  const [gpu, setGpu] = useState(38);

  useEffect(() => {
    const tick = () => {
      setCpu((v) => clamp(v + jitter(8),  15, 95));
      setRam((v) => clamp(v + jitter(4),  25, 90));
      setGpu((v) => clamp(v + jitter(10), 10, 98));
    };
    const id = setInterval(tick, 1800);
    return () => clearInterval(id);
  }, []);

  return { cpu: Math.round(cpu), ram: Math.round(ram), gpu: Math.round(gpu) };
}

const jitter = (range) => (Math.random() - 0.5) * range;
const clamp  = (v, min, max) => Math.max(min, Math.min(max, v));
