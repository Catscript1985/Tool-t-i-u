import { COLORS, FONTS } from "../utils/theme";

// ─── GlowCard ────────────────────────────────────────────────────────────────
export function GlowCard({ children, style = {}, glow = false, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: COLORS.card,
        borderRadius: 12,
        border: `1px solid ${glow ? COLORS.cyan + "44" : COLORS.border}`,
        padding: 16,
        position: "relative",
        overflow: "hidden",
        boxShadow: glow ? `0 0 24px ${COLORS.cyan}22, inset 0 0 32px ${COLORS.cyan}08` : "none",
        cursor: onClick ? "pointer" : "default",
        transition: "border-color 0.2s, box-shadow 0.2s",
        ...style,
      }}
    >
      {glow && (
        <div style={{
          position: "absolute", inset: 0, borderRadius: 12, pointerEvents: "none",
          background: `radial-gradient(ellipse at top left, ${COLORS.cyan}08, transparent 60%)`,
        }} />
      )}
      {children}
    </div>
  );
}

// ─── StatBar ─────────────────────────────────────────────────────────────────
export function StatBar({ label, value, color = COLORS.cyan, delay = 0 }) {
  return (
    <div style={{ marginBottom: 10, animation: `fadeInUp 0.5s ${delay}s both` }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: 11, color: COLORS.muted }}>{label}</span>
        <span style={{ fontSize: 11, color, fontFamily: FONTS.display }}>{value}%</span>
      </div>
      <div style={{ height: 4, background: "#ffffff10", borderRadius: 2, overflow: "hidden" }}>
        <div style={{
          height: "100%", width: `${value}%`, borderRadius: 2,
          background: `linear-gradient(90deg, ${color}88, ${color})`,
          animation: `bar-fill 1s ${delay}s both`,
          boxShadow: `0 0 8px ${color}66`,
          transition: "width 0.6s ease",
        }} />
      </div>
    </div>
  );
}

// ─── MetricRing ──────────────────────────────────────────────────────────────
export function MetricRing({ value, label, color = COLORS.cyan, size = 90 }) {
  const r    = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (value / 100) * circ;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)", position: "absolute" }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#ffffff10" strokeWidth={5} />
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={5}
            strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color})`, transition: "stroke-dasharray 0.6s ease" }} />
        </svg>
        <div style={{
          position: "absolute", inset: 0,
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        }}>
          <span style={{ fontFamily: FONTS.display, fontSize: 15, fontWeight: 700, color }}>{value}</span>
          <span style={{ fontSize: 9, color: COLORS.muted, marginTop: 1 }}>{label}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Badge ───────────────────────────────────────────────────────────────────
export function Badge({ label, color = COLORS.cyan }) {
  return (
    <span style={{
      fontSize: 9, padding: "2px 7px", borderRadius: 10, fontWeight: 700,
      background: `${color}22`, color, border: `1px solid ${color}44`,
    }}>{label}</span>
  );
}

// ─── SectionTitle ────────────────────────────────────────────────────────────
export function SectionTitle({ children, sub }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontFamily: FONTS.display, fontSize: 22, fontWeight: 700, color: "#fff", letterSpacing: 1 }}>
        {children}
      </div>
      {sub && <div style={{ fontSize: 12, color: COLORS.muted, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

// ─── CyberButton ─────────────────────────────────────────────────────────────
export function CyberButton({ children, onClick, variant = "primary", style = {} }) {
  const isPrimary = variant === "primary";
  return (
    <button
      onClick={onClick}
      style={{
        padding: "9px 20px", borderRadius: 8, border: isPrimary ? "none" : `1px solid ${COLORS.cyan}44`,
        cursor: "pointer",
        background: isPrimary ? `linear-gradient(90deg, ${COLORS.cyan}, ${COLORS.teal})` : `${COLORS.cyan}12`,
        color: isPrimary ? COLORS.dark : COLORS.cyan,
        fontFamily: FONTS.display, fontSize: 11, fontWeight: 700, letterSpacing: 1,
        boxShadow: isPrimary ? `0 0 16px ${COLORS.cyan}66` : "none",
        transition: "all 0.2s",
        ...style,
      }}
    >
      {children}
    </button>
  );
}
