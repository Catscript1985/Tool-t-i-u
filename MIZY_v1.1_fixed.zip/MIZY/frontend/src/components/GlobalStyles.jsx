import { COLORS } from "../utils/theme";

export default function GlobalStyles() {
  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Exo+2:wght@300;400;500;600&display=swap');

    *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      background: ${COLORS.dark};
      color: ${COLORS.text};
      font-family: 'Exo 2', sans-serif;
      overflow: hidden;
    }

    ::-webkit-scrollbar       { width: 4px; }
    ::-webkit-scrollbar-track { background: ${COLORS.dark}; }
    ::-webkit-scrollbar-thumb { background: ${COLORS.cyan}33; border-radius: 2px; }

    /* ── Animations ── */
    @keyframes glow-text {
      0%, 100% { text-shadow: 0 0 8px ${COLORS.cyan}88; }
      50%       { text-shadow: 0 0 24px ${COLORS.cyan}, 0 0 48px ${COLORS.cyan}66; }
    }
    @keyframes scan-line {
      0%   { transform: translateY(-100vh); }
      100% { transform: translateY(100vh); }
    }
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50%       { transform: translateY(-6px); }
    }
    @keyframes spin-slow {
      from { transform: rotate(0deg); }
      to   { transform: rotate(360deg); }
    }
    @keyframes bar-fill {
      from { width: 0; }
    }
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(16px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes blink {
      0%, 100% { opacity: 1; }
      50%       { opacity: 0; }
    }
    @keyframes ai-dots {
      0%, 80%, 100% { opacity: 0; transform: scale(0.6); }
      40%            { opacity: 1; transform: scale(1); }
    }

    .page-enter { animation: fadeInUp 0.4s both; }
  `;
  return <style dangerouslySetInnerHTML={{ __html: css }} />;
}
