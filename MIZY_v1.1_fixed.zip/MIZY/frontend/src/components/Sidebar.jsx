import { COLORS, FONTS } from "../utils/theme";
import { StatBar } from "./UI";

const NAV_SECTIONS = [
  {
    label: "TỔNG QUAN",
    items: [
      { id: "dashboard",  icon: "⚡", label: "Dashboard" },
      { id: "benchmark",  icon: "📊", label: "Benchmark" },
    ],
  },
  {
    label: "AI TOOLS",
    items: [
      { id: "ai-chat",      icon: "🤖", label: "AI Assistant",   badge: "NEW" },
      { id: "ai-profile",   icon: "🎯", label: "AI Auto-Profile" },
      { id: "ai-diagnosis", icon: "🔬", label: "AI Diagnosis" },
      { id: "ai-analysis",  icon: "🧠", label: "AI Analysis",    badge: "NEW" },
    ],
  },
  {
    label: "CHỨC NĂNG",
    items: [
      { id: "tweaks",   icon: "🔧", label: "Tweaks"           },
      { id: "network",  icon: "📡", label: "Network Optimizer" },
      { id: "cleaner",  icon: "🧹", label: "System Cleaner"   },
      { id: "settings", icon: "⚙️", label: "Cài đặt"          },
    ],
  },
];

function NavItem({ icon, label, active, onClick, badge }) {
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex", alignItems: "center", gap: 10, width: "100%",
        padding: "9px 14px", borderRadius: 8, border: "none", cursor: "pointer",
        background: active ? "linear-gradient(90deg,#00e5ff18,transparent)" : "transparent",
        borderLeft: active ? `2px solid ${COLORS.cyan}` : "2px solid transparent",
        color: active ? COLORS.cyan : COLORS.muted,
        fontFamily: FONTS.body, fontSize: 12, fontWeight: 500,
        transition: "all 0.2s",
      }}
    >
      <span style={{ fontSize: 14 }}>{icon}</span>
      <span style={{ flex: 1, textAlign: "left" }}>{label}</span>
      {badge && (
        <span style={{
          background: COLORS.cyan, color: COLORS.dark,
          borderRadius: 10, fontSize: 9, fontWeight: 700, padding: "1px 6px",
        }}>{badge}</span>
      )}
    </button>
  );
}

export default function Sidebar({ activeNav, setActiveNav, cpu, ram, gpu, appliedCount }) {
  const cpuColor = cpu > 75 ? COLORS.red  : COLORS.cyan;
  const gpuColor = gpu > 80 ? COLORS.red  : COLORS.green;
  const ramColor = ram > 80 ? COLORS.warn : COLORS.teal;

  return (
    <aside style={{
      width: 200, background: COLORS.sidebar,
      borderRight: `1px solid ${COLORS.border}`,
      display: "flex", flexDirection: "column", zIndex: 10, flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{ padding: "20px 14px 16px", borderBottom: `1px solid ${COLORS.border}` }}>
        <div style={{
          fontFamily: FONTS.display, fontSize: 28, fontWeight: 900,
          color: COLORS.cyan, letterSpacing: 3,
          animation: "glow-text 3s ease-in-out infinite",
        }}>MIZY</div>
        <div style={{ fontSize: 9, color: COLORS.muted, letterSpacing: 2, marginTop: 2 }}>
          SYSTEM OPTIMIZER
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, overflowY: "auto", padding: "10px 8px" }}>
        {NAV_SECTIONS.map((sec) => (
          <div key={sec.label} style={{ marginBottom: 16 }}>
            <div style={{
              fontSize: 9, color: COLORS.dim, letterSpacing: 2,
              fontWeight: 700, padding: "0 6px", marginBottom: 6,
            }}>{sec.label}</div>
            {sec.items.map((item) => (
              <NavItem
                key={item.id}
                {...item}
                badge={item.id === "tweaks" ? String(appliedCount) : item.badge}
                active={activeNav === item.id}
                onClick={() => setActiveNav(item.id)}
              />
            ))}
          </div>
        ))}
      </nav>

      {/* Live Metrics */}
      <div style={{ padding: 12, borderTop: `1px solid ${COLORS.border}` }}>
        <div style={{ fontSize: 9, color: COLORS.dim, letterSpacing: 2, marginBottom: 8 }}>
          SYSTEM LIVE
        </div>
        <StatBar label="CPU" value={cpu} color={cpuColor} delay={0}   />
        <StatBar label="GPU" value={gpu} color={gpuColor} delay={0.1} />
        <StatBar label="RAM" value={ram} color={ramColor} delay={0.2} />
      </div>

      {/* User */}
      <div style={{
        padding: "10px 14px", borderTop: `1px solid ${COLORS.border}`,
        display: "flex", alignItems: "center", gap: 8,
      }}>
        <div style={{
          width: 30, height: 30, borderRadius: "50%",
          background: `linear-gradient(135deg,${COLORS.cyan},#006d82)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 13, fontWeight: 700, color: COLORS.dark,
          boxShadow: `0 0 10px ${COLORS.cyan}55`,
        }}>U</div>
        <div>
          <div style={{ fontSize: 11, color: "#d0ecf0", fontWeight: 600 }}>User</div>
          <div style={{ fontSize: 9, color: COLORS.cyan }}>PREMIUM</div>
        </div>
      </div>
    </aside>
  );
}
