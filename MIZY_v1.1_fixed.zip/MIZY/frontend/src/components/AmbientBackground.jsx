import { COLORS } from "../utils/theme";

export default function AmbientBackground() {
  return (
    <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
      <div style={{
        position: "absolute", top: "-20%", left: "30%",
        width: "60vw", height: "60vw", borderRadius: "50%",
        background: `radial-gradient(circle, ${COLORS.cyan}06, transparent 65%)`,
      }} />
      <div style={{
        position: "absolute", bottom: "-10%", right: "-10%",
        width: "40vw", height: "40vw", borderRadius: "50%",
        background: `radial-gradient(circle, #0077b622, transparent 65%)`,
      }} />
      <div style={{
        position: "absolute", top: 0, left: "50%", width: 1, height: "100vh",
        background: `linear-gradient(to bottom, transparent, ${COLORS.cyan}08, transparent)`,
        animation: "scan-line 10s linear infinite", opacity: 0.4,
      }} />
    </div>
  );
}
