// ─── MIZY Design Tokens ───────────────────────────────────────────────────────
export const COLORS = {
  cyan:   "#00e5ff",
  teal:   "#00b4d8",
  dark:   "#060d14",
  card:   "#0a1628",
  card2:  "#0d1f35",
  sidebar:"#06101a",
  border: "rgba(0,229,255,0.15)",
  green:  "#00d4aa",
  purple: "#7c83fd",
  gold:   "#ffd180",
  red:    "#ff6b6b",
  warn:   "#ffd166",
  text:   "#e0f7fa",
  muted:  "#7aadbb",
  dim:    "#3a6070",
};

export const FONTS = {
  display: "'Orbitron', monospace",
  body:    "'Exo 2', sans-serif",
};
