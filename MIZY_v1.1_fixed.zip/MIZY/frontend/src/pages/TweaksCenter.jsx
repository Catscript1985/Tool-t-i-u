import { GlowCard, SectionTitle, CyberButton } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

const IMPACT_STYLE = {
  HIGH: { bg: "#ff6b6b22", color: "#ff8a80", border: "#ff6b6b44" },
  MED:  { bg: "#ffd16622", color: "#ffd180", border: "#ffd16644" },
  LOW:  { bg: "#00e5ff22", color: "#00e5ff", border: "#00e5ff44" },
};

function TweakRow({ name, category, impact, applied, onToggle }) {
  const s = IMPACT_STYLE[impact];
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "8px 12px", borderRadius: 8, marginBottom: 4,
      background: applied ? `${COLORS.cyan}08` : "transparent",
      border: `1px solid ${applied ? COLORS.cyan + "22" : "transparent"}`,
      transition: "all 0.2s",
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12, color: "#d0ecf0", fontWeight: 500 }}>{name}</div>
        <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 1 }}>{category}</div>
      </div>
      <span style={{
        fontSize: 9, padding: "2px 7px", borderRadius: 10, fontWeight: 600,
        background: s.bg, color: s.color, border: `1px solid ${s.border}`,
      }}>{impact}</span>
      <button onClick={onToggle} style={{
        width: 36, height: 20, borderRadius: 10, border: "none", cursor: "pointer",
        background: applied ? `linear-gradient(90deg,${COLORS.cyan},${COLORS.teal})` : "#ffffff15",
        position: "relative", transition: "all 0.2s",
        boxShadow: applied ? `0 0 10px ${COLORS.cyan}66` : "none",
      }}>
        <div style={{
          position: "absolute", top: 2, left: applied ? 18 : 2,
          width: 16, height: 16, borderRadius: "50%", background: "#fff",
          transition: "left 0.2s", boxShadow: "0 1px 3px #000a",
        }} />
      </button>
    </div>
  );
}

export default function TweaksCenter({ tweaks, toggleTweak, applyAll, appliedCount, total }) {
  return (
    <div className="page-enter">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 20 }}>
        <SectionTitle sub={`${appliedCount} / ${total} tweaks đang active`}>
          🔧 TWEAKS <span style={{ color: COLORS.cyan }}>CENTER</span>
        </SectionTitle>
        <CyberButton onClick={applyAll} style={{ letterSpacing: 1 }}>APPLY ALL</CyberButton>
      </div>

      <GlowCard glow style={{ padding: 12 }}>
        {tweaks.map((t, i) => (
          <TweakRow key={t.name} {...t} onToggle={() => toggleTweak(i)} />
        ))}
      </GlowCard>
    </div>
  );
}
