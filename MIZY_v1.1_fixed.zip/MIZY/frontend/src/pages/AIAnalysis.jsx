import { useState } from "react";
import { GlowCard, SectionTitle, CyberButton, Badge } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

// Simulated full AI analysis result (in production: fetch from /api/ai/analyze)
const MOCK_ANALYSIS = {
  pc_class: "mid_range",
  bottleneck: "CPU",
  health_score: 72,
  hardware: { cpu: "Ryzen 5 7640HS", gpu: "Radeon 760M (iGPU)", ram: "16GB", disk: "NVMe" },
  tweaks: [
    { id: "timer_resolution",      priority: 9, reason: "AMD Zen4 scheduler cần timer chính xác" },
    { id: "power_plan_ultimate",   priority: 9, reason: "Loại bỏ CPU throttling hoàn toàn" },
    { id: "disable_nagle",         priority: 9, reason: "Giảm TCP latency đáng kể" },
    { id: "disable_xbox_gamebar",  priority: 8, reason: "Giảm CPU overhead" },
    { id: "gpu_hw_scheduling",     priority: 7, reason: "iGPU hỗ trợ HW scheduling từ Win11" },
    { id: "disable_superfetch",    priority: 6, reason: "RAM 16GB đủ, Superfetch không cần" },
    { id: "network_tuner",         priority: 6, reason: "Tuner RSS & chimney" },
    { id: "disable_telemetry",     priority: 5, reason: "Giảm background tasks" },
  ],
  warnings: [
    "ℹ️ iGPU — Chia sẻ RAM với CPU, FPS sẽ bị giới hạn hơn GPU rời",
    "🟡 Laptop: Cắm sạc khi gaming để tránh CPU/GPU throttle",
  ],
  tips: [
    "Cắm sạc khi gaming để tránh CPU/GPU throttle",
    "AMD CPU + AMD iGPU: Bật SAM trong BIOS nếu hỗ trợ",
    "Dùng laptop cooler pad để hạ nhiệt hiệu quả",
  ],
  estimated_fps:  "+12–20 FPS (ước tính)",
  estimated_ping: "−25–35ms ping (ước tính)",
  ai_summary: "MIZY phân tích: Laptop — Health Score 72/100 (Grade B).\nBottleneck chính: CPU (Ryzen 5 7640HS).\nMục tiêu: FPS.\nHệ thống: Ryzen 5 7640HS | 16GB RAM | Radeon 760M | NVMe.",
  ai_architecture: "Rule-Based Expert System + Weighted Scoring Model\n→ Không cần internet, không cần API key\n→ Chạy 100% local, deterministic, <1ms response time",
};

const GOAL_OPTIONS = [
  { id: "fps",       label: "🎮 Max FPS",       desc: "Ưu tiên tăng FPS tối đa" },
  { id: "latency",   label: "⚡ Ultra Latency",  desc: "Giảm ping & lag spike" },
  { id: "stability", label: "🛡️ Stability",       desc: "Ổn định, không drop" },
  { id: "battery",   label: "🔋 Battery Saver",  desc: "Laptop tiết kiệm pin" },
  { id: "balanced",  label: "⚖️ Balanced",        desc: "Cân bằng mọi thứ" },
];

function ScoreRing({ score }) {
  const size   = 110;
  const r      = (size - 12) / 2;
  const circ   = 2 * Math.PI * r;
  const dash   = (score / 100) * circ;
  const grade  = score >= 90 ? "S" : score >= 75 ? "A" : score >= 55 ? "B" : score >= 35 ? "C" : "D";
  const color  = score >= 75 ? COLORS.cyan : score >= 55 ? COLORS.gold : COLORS.red;

  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)", position: "absolute" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#ffffff10" strokeWidth={7} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={7}
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ filter: `drop-shadow(0 0 8px ${color})`, transition: "stroke-dasharray 1s ease" }} />
      </svg>
      <div style={{
        position: "absolute", inset: 0,
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      }}>
        <span style={{ fontFamily: FONTS.display, fontSize: 22, fontWeight: 900, color }}>{score}</span>
        <span style={{ fontSize: 10, color: COLORS.muted }}>Grade {grade}</span>
      </div>
    </div>
  );
}

function TweakPill({ id, priority, reason }) {
  const pColor = priority >= 9 ? COLORS.red : priority >= 7 ? COLORS.gold : COLORS.cyan;
  return (
    <div style={{
      padding: "8px 12px", borderRadius: 8, marginBottom: 6,
      background: "#ffffff06", border: `1px solid ${COLORS.border}`,
      display: "flex", alignItems: "center", gap: 10,
    }}>
      <span style={{
        width: 24, height: 24, borderRadius: 6, flexShrink: 0,
        background: `${pColor}22`, border: `1px solid ${pColor}44`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 9, fontWeight: 700, color: pColor,
      }}>{priority}</span>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "#d0ecf0", fontWeight: 600 }}>{id.replace(/_/g, " ").toUpperCase()}</div>
        <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 1 }}>{reason}</div>
      </div>
      <span style={{
        fontSize: 9, padding: "1px 6px", borderRadius: 8,
        background: `${pColor}15`, color: pColor, border: `1px solid ${pColor}33`,
      }}>{priority >= 9 ? "HIGH" : priority >= 7 ? "MED" : "LOW"}</span>
    </div>
  );
}

export default function AIAnalysis() {
  const [goal,     setGoal]     = useState("fps");
  const [scanning, setScanning] = useState(false);
  const [result,   setResult]   = useState(null);

  const runAnalysis = () => {
    setScanning(true);
    setResult(null);
    // Simulate AI analysis (replace with: fetch('/api/ai/analyze', {method:'POST', body: JSON.stringify({goal})}) )
    setTimeout(() => {
      setScanning(false);
      setResult({ ...MOCK_ANALYSIS });
    }, 2200);
  };

  return (
    <div className="page-enter">
      <SectionTitle sub="AI phân tích phần cứng → kế hoạch tối ưu tuyệt đối cho máy bạn">
        🧠 AI <span style={{ color: COLORS.cyan }}>HARDWARE ANALYSIS</span>
      </SectionTitle>

      {/* Goal selector */}
      <GlowCard style={{ marginBottom: 14 }}>
        <div style={{ fontFamily: FONTS.display, fontSize: 12, color: COLORS.muted, marginBottom: 10, letterSpacing: 1 }}>
          CHỌN MỤC TIÊU TỐI ƯU
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8, marginBottom: 14 }}>
          {GOAL_OPTIONS.map((g) => (
            <button key={g.id} onClick={() => setGoal(g.id)} style={{
              padding: "10px 8px", borderRadius: 8, border: "none", cursor: "pointer",
              background: goal === g.id ? `${COLORS.cyan}20` : "#ffffff08",
              borderTop: goal === g.id ? `2px solid ${COLORS.cyan}` : "2px solid transparent",
              color: goal === g.id ? COLORS.cyan : COLORS.muted,
              fontFamily: FONTS.body, fontSize: 10, fontWeight: goal === g.id ? 700 : 400,
              textAlign: "center", transition: "all 0.2s",
            }}>
              <div style={{ fontSize: 16, marginBottom: 4 }}>{g.label.split(" ")[0]}</div>
              <div>{g.label.split(" ").slice(1).join(" ")}</div>
            </button>
          ))}
        </div>
        <CyberButton onClick={runAnalysis} style={{ width: "100%", padding: 12, letterSpacing: 2, fontSize: 13 }}>
          {scanning ? "⏳ ĐANG PHÂN TÍCH..." : "🧠 PHÂN TÍCH PHẦN CỨNG NGAY"}
        </CyberButton>
      </GlowCard>

      {/* Scanning animation */}
      {scanning && (
        <GlowCard glow style={{ textAlign: "center", padding: 40, animation: "fadeInUp 0.3s both" }}>
          <div style={{
            width: 60, height: 60, borderRadius: "50%", margin: "0 auto 16px",
            border: `3px solid ${COLORS.border}`, borderTop: `3px solid ${COLORS.cyan}`,
            animation: "spin-slow 0.8s linear infinite",
          }} />
          <div style={{ fontFamily: FONTS.display, fontSize: 14, color: COLORS.cyan, marginBottom: 6 }}>
            AI ĐANG PHÂN TÍCH...
          </div>
          <div style={{ fontSize: 11, color: COLORS.muted }}>
            Đọc CPU · RAM · GPU · Disk · Network
          </div>
        </GlowCard>
      )}

      {/* Result */}
      {result && (
        <div style={{ animation: "fadeInUp 0.4s both" }}>

          {/* Header cards */}
          <div style={{ display: "grid", gridTemplateColumns: "auto 1fr 1fr", gap: 14, marginBottom: 14 }}>
            {/* Health score */}
            <GlowCard glow style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
              <ScoreRing score={result.health_score} />
            </GlowCard>

            {/* Hardware fingerprint */}
            <GlowCard>
              <div style={{ fontFamily: FONTS.display, fontSize: 11, color: COLORS.muted, marginBottom: 10, letterSpacing: 1 }}>
                HARDWARE DETECTED
              </div>
              {Object.entries(result.hardware).map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontSize: 10, color: COLORS.muted, textTransform: "uppercase" }}>{k}</span>
                  <span style={{ fontSize: 10, color: "#d0ecf0", fontWeight: 600 }}>{v}</span>
                </div>
              ))}
            </GlowCard>

            {/* Estimates */}
            <GlowCard>
              <div style={{ fontFamily: FONTS.display, fontSize: 11, color: COLORS.muted, marginBottom: 10, letterSpacing: 1 }}>
                AI ESTIMATES
              </div>
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 2 }}>FPS GAIN</div>
                <div style={{ fontFamily: FONTS.display, fontSize: 16, color: COLORS.cyan,
                  textShadow: `0 0 12px ${COLORS.cyan}` }}>{result.estimated_fps}</div>
              </div>
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 2 }}>PING REDUCTION</div>
                <div style={{ fontFamily: FONTS.display, fontSize: 16, color: COLORS.green,
                  textShadow: `0 0 12px ${COLORS.green}` }}>{result.estimated_ping}</div>
              </div>
              <div>
                <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 4 }}>BOTTLENECK</div>
                <Badge label={result.bottleneck} color={COLORS.red} />
              </div>
            </GlowCard>
          </div>

          {/* AI Summary */}
          <GlowCard glow style={{ marginBottom: 14 }}>
            <div style={{ fontFamily: FONTS.display, fontSize: 12, color: COLORS.cyan, marginBottom: 8, letterSpacing: 1 }}>
              🧠 AI SUMMARY
            </div>
            <div style={{ fontSize: 12, color: "#b0d4dd", lineHeight: 1.7, whiteSpace: "pre-line" }}>
              {result.ai_summary}
            </div>
            <div style={{
              marginTop: 12, padding: "8px 12px", borderRadius: 8,
              background: "#ffffff06", border: `1px solid ${COLORS.border}`,
              fontSize: 10, color: COLORS.muted, whiteSpace: "pre-line",
              fontFamily: FONTS.display, letterSpacing: 0.5,
            }}>
              ⚙️ AI ARCHITECTURE:{"\n"}{result.ai_architecture}
            </div>
          </GlowCard>

          {/* Tweaks + Warnings 2 col */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
            {/* Recommended tweaks */}
            <GlowCard>
              <div style={{ fontFamily: FONTS.display, fontSize: 12, color: "#fff", marginBottom: 10, letterSpacing: 1 }}>
                ⚡ TWEAKS ĐỀ XUẤT ({result.tweaks.length})
              </div>
              <div style={{ maxHeight: 280, overflowY: "auto" }}>
                {result.tweaks.map((t) => <TweakPill key={t.id} {...t} />)}
              </div>
              <CyberButton style={{ width: "100%", marginTop: 10 }}>APPLY ALL TWEAKS</CyberButton>
            </GlowCard>

            {/* Warnings + Tips */}
            <div>
              <GlowCard style={{ marginBottom: 14 }}>
                <div style={{ fontFamily: FONTS.display, fontSize: 12, color: "#fff", marginBottom: 10, letterSpacing: 1 }}>
                  ⚠️ WARNINGS
                </div>
                {result.warnings.map((w, i) => (
                  <div key={i} style={{ fontSize: 11, color: "#b0d4dd", lineHeight: 1.6, marginBottom: 6 }}>{w}</div>
                ))}
              </GlowCard>
              <GlowCard>
                <div style={{ fontFamily: FONTS.display, fontSize: 12, color: "#fff", marginBottom: 10, letterSpacing: 1 }}>
                  💡 TIPS
                </div>
                {result.tips.map((t, i) => (
                  <div key={i} style={{
                    fontSize: 11, color: "#b0d4dd", lineHeight: 1.6, marginBottom: 6,
                    paddingLeft: 10, borderLeft: `2px solid ${COLORS.cyan}44`,
                  }}>• {t}</div>
                ))}
              </GlowCard>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
