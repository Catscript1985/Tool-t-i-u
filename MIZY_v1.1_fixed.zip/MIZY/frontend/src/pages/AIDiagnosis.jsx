import { GlowCard, SectionTitle } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

const ISSUES = [
  {
    icon: "🔴", title: "DPC Latency Spike", severity: "CRITICAL",
    desc: "Phát hiện interrupt latency đột biến lên 2.4ms — gây frame drop đột ngột. Nguyên nhân: USB driver conflict.",
    fix: "Auto Fix Available", time: "2 giờ trước",
  },
  {
    icon: "🟡", title: "Network Bufferbloat", severity: "WARNING",
    desc: "Bufferbloat level B — ping dao động ±35ms khi tải file. Ảnh hưởng nghiêm trọng đến game online.",
    fix: "Apply Network Tweaks", time: "5 giờ trước",
  },
  {
    icon: "🟡", title: "GPU Memory Leak", severity: "WARNING",
    desc: "VRAM usage tăng dần theo thời gian, không tự giải phóng. Driver cần cập nhật hoặc reset.",
    fix: "Restart GPU Driver", time: "Hôm nay",
  },
  {
    icon: "🟢", title: "CPU Temperature", severity: "NORMAL",
    desc: "Nhiệt độ CPU ổn định 72°C dưới full load — trong ngưỡng an toàn.",
    fix: null, time: "Monitoring",
  },
];

const SEVERITY_STYLE = {
  CRITICAL: { bg: "#ff6b6b22", color: "#ff8a80" },
  WARNING:  { bg: "#ffd16622", color: "#ffd180" },
  NORMAL:   { bg: "#00ff8822", color: "#00ff88" },
};

export default function AIDiagnosis() {
  return (
    <div className="page-enter">
      <SectionTitle sub="AI phân tích sâu và dự đoán vấn đề trước khi xảy ra">
        🔬 AI <span style={{ color: COLORS.cyan }}>DIAGNOSIS</span>
      </SectionTitle>

      <div style={{ display: "grid", gap: 12 }}>
        {ISSUES.map((d, i) => {
          const s = SEVERITY_STYLE[d.severity];
          return (
            <GlowCard key={d.title} style={{ animation: `fadeInUp 0.4s ${i * 0.1}s both` }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <span style={{ fontSize: 24, flexShrink: 0 }}>{d.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                    <div style={{ fontFamily: FONTS.display, fontSize: 12, fontWeight: 700, color: "#fff" }}>
                      {d.title}
                    </div>
                    <span style={{
                      fontSize: 9, padding: "2px 8px", borderRadius: 10, fontWeight: 700,
                      background: s.bg, color: s.color,
                    }}>{d.severity}</span>
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.muted, lineHeight: 1.5, marginBottom: 8 }}>
                    {d.desc}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 9, color: COLORS.dim }}>{d.time}</span>
                    {d.fix && (
                      <button style={{
                        padding: "4px 10px", borderRadius: 6,
                        border: `1px solid ${COLORS.cyan}44`, cursor: "pointer",
                        background: `${COLORS.cyan}12`, color: COLORS.cyan,
                        fontFamily: FONTS.body, fontSize: 10, fontWeight: 600,
                      }}>{d.fix} →</button>
                    )}
                  </div>
                </div>
              </div>
            </GlowCard>
          );
        })}
      </div>
    </div>
  );
}
