import { useState } from "react";
import { GlowCard, SectionTitle, CyberButton } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

const PROFILES = [
  { icon: "🎮", name: "FPS Gaming",        desc: "Tối ưu cho CS2, Valorant, Warzone",   tweaks: 47, gain: "+22 FPS avg",  color: COLORS.cyan   },
  { icon: "🎯", name: "Ultra Low Latency", desc: "Giảm latency tối đa, ping cực thấp",  tweaks: 38, gain: "-18ms ping",   color: COLORS.green  },
  { icon: "🖥️", name: "Balanced Work",     desc: "Cân bằng hiệu năng và tiết kiệm pin", tweaks: 24, gain: "+40% battery", color: COLORS.purple },
  { icon: "🚀", name: "Max Performance",   desc: "Toàn bộ tweaks, dành cho PC bàn",     tweaks: 89, gain: "+35 FPS avg",  color: COLORS.gold   },
];

const APPLIED_TWEAKS = [
  "CPU Priority → High", "HPET → Disabled", "Network Stack → Tuned",
  "GPU Scheduling → On", "Timer Res → 0.5ms", "DPC Latency → Fixed",
];

export default function AIProfile() {
  const [active, setActive] = useState(null);

  return (
    <div className="page-enter">
      <SectionTitle sub="AI tự động phân tích và tạo profile tối ưu cá nhân hóa">
        🎯 AI <span style={{ color: COLORS.cyan }}>AUTO-PROFILE</span>
      </SectionTitle>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        {PROFILES.map((p, i) => (
          <GlowCard
            key={p.name} glow={active === p.name} onClick={() => setActive(p.name)}
            style={{ cursor: "pointer", animation: `fadeInUp 0.4s ${i * 0.1}s both` }}
          >
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 10 }}>
              <span style={{ fontSize: 28 }}>{p.icon}</span>
              {active === p.name && (
                <span style={{
                  fontSize: 9, padding: "2px 8px", borderRadius: 10, fontWeight: 700,
                  background: `${p.color}22`, color: p.color, border: `1px solid ${p.color}44`,
                }}>ACTIVE</span>
              )}
            </div>
            <div style={{ fontFamily: FONTS.display, fontSize: 13, fontWeight: 700, color: "#fff", marginBottom: 4 }}>
              {p.name}
            </div>
            <div style={{ fontSize: 11, color: COLORS.muted, marginBottom: 10 }}>{p.desc}</div>
            <div style={{ display: "flex", gap: 10 }}>
              <span style={{
                padding: "3px 8px", borderRadius: 6, fontSize: 10,
                background: `${p.color}15`, border: `1px solid ${p.color}33`, color: p.color,
              }}>{p.tweaks} tweaks</span>
              <span style={{
                padding: "3px 8px", borderRadius: 6, fontSize: 10,
                background: "#ffffff10", color: "#d0ecf0",
              }}>{p.gain}</span>
            </div>
          </GlowCard>
        ))}
      </div>

      {active && (
        <GlowCard glow style={{ animation: "fadeInUp 0.3s both" }}>
          <div style={{ fontFamily: FONTS.display, fontSize: 13, fontWeight: 700, color: COLORS.cyan, marginBottom: 12 }}>
            AI ANALYSIS — {active.toUpperCase()}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
            {APPLIED_TWEAKS.map((t) => (
              <div key={t} style={{
                padding: "6px 10px", borderRadius: 6,
                background: `${COLORS.cyan}0a`, border: `1px solid ${COLORS.cyan}22`,
                fontSize: 10, color: "#b0d4dd",
              }}>✓ {t}</div>
            ))}
          </div>
          <CyberButton style={{ width: "100%", padding: 10, letterSpacing: 2 }}>
            APPLY PROFILE NOW
          </CyberButton>
        </GlowCard>
      )}
    </div>
  );
}
