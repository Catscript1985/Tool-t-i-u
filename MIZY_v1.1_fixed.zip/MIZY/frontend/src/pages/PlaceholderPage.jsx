import { COLORS, FONTS } from "../utils/theme";

export default function PlaceholderPage({ icon, title, version }) {
  return (
    <div className="page-enter" style={{
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center", height: "60vh",
    }}>
      <div style={{ fontSize: 64, marginBottom: 16, animation: "float 3s ease-in-out infinite" }}>
        {icon}
      </div>
      <div style={{ fontFamily: FONTS.display, fontSize: 18, fontWeight: 700, color: "#fff", marginBottom: 8 }}>
        {title}
      </div>
      <div style={{ fontSize: 12, color: COLORS.muted }}>Coming in MIZY v{version}</div>
    </div>
  );
}
