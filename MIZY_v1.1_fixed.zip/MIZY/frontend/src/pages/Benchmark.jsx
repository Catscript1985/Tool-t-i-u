import { useState } from "react";
import { GlowCard, SectionTitle, CyberButton } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

// ─── Benchmark ───────────────────────────────────────────────────────────────
export function Benchmark() {
  const [score,   setScore]   = useState(null);
  const [running, setRunning] = useState(false);

  const run = () => {
    setRunning(true); setScore(null);
    setTimeout(() => { setScore(8742); setRunning(false); }, 3000);
  };

  return (
    <div className="page-enter">
      <SectionTitle sub="AI giải thích kết quả benchmark bằng ngôn ngữ tự nhiên">
        📊 <span style={{ color: COLORS.cyan }}>BENCHMARK</span>
      </SectionTitle>

      <GlowCard glow style={{ textAlign: "center", padding: 40 }}>
        {!score && !running && (
          <>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📊</div>
            <div style={{ fontFamily: FONTS.display, fontSize: 14, color: COLORS.muted, marginBottom: 20 }}>
              Chưa có dữ liệu benchmark
            </div>
            <CyberButton onClick={run} style={{ padding: "12px 32px", letterSpacing: 2 }}>
              RUN BENCHMARK
            </CyberButton>
          </>
        )}

        {running && (
          <div style={{ animation: "fadeInUp 0.3s both" }}>
            <div style={{
              width: 80, height: 80, borderRadius: "50%", margin: "0 auto 20px",
              border: `3px solid ${COLORS.border}`, borderTop: `3px solid ${COLORS.cyan}`,
              animation: "spin-slow 1s linear infinite",
            }} />
            <div style={{ fontFamily: FONTS.display, fontSize: 14, color: COLORS.cyan }}>
              RUNNING...
            </div>
          </div>
        )}

        {score && !running && (
          <div style={{ animation: "fadeInUp 0.4s both" }}>
            <div style={{
              fontFamily: FONTS.display, fontSize: 72, fontWeight: 900,
              color: COLORS.cyan, textShadow: `0 0 40px ${COLORS.cyan}`, marginBottom: 4,
            }}>{score.toLocaleString()}</div>
            <div style={{ fontSize: 14, color: COLORS.muted, marginBottom: 20 }}>MIZY SCORE</div>
            <div style={{
              padding: "12px 20px", borderRadius: 10,
              background: `${COLORS.cyan}12`, border: `1px solid ${COLORS.cyan}33`,
              fontSize: 12, color: "#b0d4dd", textAlign: "left", lineHeight: 1.7,
            }}>
              🤖 <b style={{ color: COLORS.cyan }}>AI Analysis:</b> Score 8,742 — top 35% người dùng MIZY.
              CPU bottleneck nhẹ ở multi-thread (-8%). GPU performance tốt. Nếu apply thêm 12 tweaks còn lại,
              dự kiến score tăng lên <b style={{ color: COLORS.cyan }}>~10,200</b>.
            </div>
          </div>
        )}
      </GlowCard>
    </div>
  );
}

export default Benchmark;
