import { useState } from "react";
import { GlowCard, MetricRing, SectionTitle, CyberButton } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";
import { TWEAKS_DATA } from "../utils/tweaksData";

export default function Dashboard({ cpu, ram, gpu, gameMode, setGameMode, appliedCount, tweaks }) {
  const safeTweaks = tweaks ?? TWEAKS_DATA;
  const [scanProgress, setScanProgress] = useState(0);
  const [scanning, setScanning]         = useState(false);
  const [scanDone, setScanDone]         = useState(false);

  const runScan = () => {
    if (scanning) return;
    setScanning(true); setScanDone(false); setScanProgress(0);
    const iv = setInterval(() => {
      setScanProgress((p) => {
        if (p >= 100) { clearInterval(iv); setScanning(false); setScanDone(true); return 100; }
        return p + 2;
      });
    }, 60);
  };

  const metrics = [
    { label: "CPU", val: cpu, color: cpu > 75 ? COLORS.red  : COLORS.cyan,  sub: "Ryzen / Intel" },
    { label: "GPU", val: gpu, color: gpu > 80 ? COLORS.red  : COLORS.green, sub: "Dedicated / iGPU" },
    { label: "RAM", val: ram, color: ram > 80 ? COLORS.warn : COLORS.teal,  sub: "DDR4 / DDR5" },
  ];

  return (
    <div className="page-enter">
      <SectionTitle sub="Real-time metrics & optimization status">
        SYSTEM <span style={{ color: COLORS.cyan }}>OVERVIEW</span>
      </SectionTitle>

      {/* Metric rings */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 14 }}>
        {metrics.map((m) => (
          <GlowCard key={m.label} glow style={{ textAlign: "center", padding: 20 }}>
            <MetricRing value={m.val} label={m.label} color={m.color} size={90} />
            <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 8 }}>{m.sub}</div>
          </GlowCard>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
        {/* Game Mode */}
        <GlowCard glow={gameMode}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div>
              <div style={{ fontFamily: FONTS.display, fontSize: 13, fontWeight: 700, color: "#fff" }}>
                🎮 GAME MODE
              </div>
              <div style={{ fontSize: 10, color: COLORS.muted, marginTop: 2 }}>
                Optimize kernel priority for gaming
              </div>
            </div>
            <CyberButton onClick={() => setGameMode((v) => !v)} variant={gameMode ? "primary" : "secondary"}>
              {gameMode ? "ACTIVE" : "ACTIVATE"}
            </CyberButton>
          </div>
          {gameMode && (
            <div style={{
              padding: "6px 10px", borderRadius: 6,
              background: `${COLORS.cyan}15`, border: `1px solid ${COLORS.cyan}33`,
              fontSize: 10, color: COLORS.cyan, animation: "fadeInUp 0.3s both",
            }}>
              ✓ Kernel priority elevated · ✓ Background apps suspended
            </div>
          )}
        </GlowCard>

        {/* Active Tweaks */}
        <GlowCard>
          <div style={{ fontFamily: FONTS.display, fontSize: 13, fontWeight: 700, color: "#fff", marginBottom: 12 }}>
            ⚡ ACTIVE TWEAKS
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{
              fontFamily: FONTS.display, fontSize: 44, fontWeight: 900,
              color: COLORS.cyan, textShadow: `0 0 20px ${COLORS.cyan}`,
            }}>{appliedCount}</div>
            <div>
              <div style={{ fontSize: 11, color: COLORS.muted }}>of {safeTweaks.length} tweaks applied</div>
              <div style={{
                marginTop: 4, fontSize: 10, padding: "2px 8px", borderRadius: 10, display: "inline-block",
                background: `${COLORS.cyan}15`, color: COLORS.cyan, border: `1px solid ${COLORS.cyan}33`,
              }}>OPTIMIZING</div>
            </div>
          </div>
        </GlowCard>
      </div>

      {/* Quick Actions */}
      <GlowCard>
        <div style={{ fontFamily: FONTS.display, fontSize: 13, fontWeight: 600, color: "#fff", marginBottom: 12 }}>
          ⚡ QUICK ACTIONS
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
          {[
            { label: "🔍 AI Scan System",    action: runScan,  active: scanning },
            { label: "🚀 Optimize Session",   action: () => {} },
            { label: "📊 Run Benchmark",      action: () => {} },
          ].map((a) => (
            <button key={a.label} onClick={a.action} style={{
              padding: "10px 12px", borderRadius: 8, border: `1px solid ${COLORS.border}`, cursor: "pointer",
              background: a.active ? `${COLORS.cyan}18` : "#ffffff08",
              color: a.active ? COLORS.cyan : "#d0ecf0",
              fontFamily: FONTS.body, fontSize: 11, fontWeight: 600, textAlign: "left", transition: "all 0.2s",
            }}>{a.label}</button>
          ))}
        </div>

        {scanning && (
          <div style={{ marginTop: 12, animation: "fadeInUp 0.3s both" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 10, color: COLORS.cyan }}>AI scanning system...</span>
              <span style={{ fontSize: 10, color: COLORS.cyan, fontFamily: FONTS.display }}>{scanProgress}%</span>
            </div>
            <div style={{ height: 4, background: "#ffffff10", borderRadius: 2 }}>
              <div style={{
                height: "100%", width: `${scanProgress}%`,
                background: `linear-gradient(90deg,${COLORS.cyan},${COLORS.teal})`,
                borderRadius: 2, transition: "width 0.1s",
                boxShadow: `0 0 8px ${COLORS.cyan}`,
              }} />
            </div>
          </div>
        )}

        {scanDone && (
          <div style={{
            marginTop: 10, padding: "8px 12px", borderRadius: 8,
            background: `${COLORS.cyan}12`, border: `1px solid ${COLORS.cyan}33`,
            fontSize: 11, color: COLORS.cyan, animation: "fadeInUp 0.3s both",
          }}>
            ✅ Scan hoàn tất! Phát hiện <b>4 vấn đề</b> — vào <b>AI Diagnosis</b> để xem chi tiết.
          </div>
        )}
      </GlowCard>
    </div>
  );
}
