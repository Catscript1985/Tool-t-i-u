import { useState, useRef, useEffect } from "react";
import { GlowCard, SectionTitle } from "../components/UI";
import { COLORS, FONTS } from "../utils/theme";

const AI_RESPONSES = {
  fps:     "🎯 Phân tích xong! CPU đang có interrupt overhead cao. Gợi ý bật: **Timer Resolution + HPET Disable + DPC Latency Fix**. Dự kiến tăng +18–25 FPS trong game FPS.",
  lag:     "⚡ Phát hiện Nagle Algorithm đang bật — nguyên nhân chính gây lag spike. Kết hợp Bufferbloat khiến ping dao động ±40ms. Sẽ fix với 3 tweaks network.",
  ping:    "🌐 Scan mạng: Bufferbloat level B+, latency ~45ms. Apply **Nagle Off + CoDel + Adapter Tuner** — dự kiến ping giảm xuống 18–22ms.",
  nhiet:   "🌡️ Nhiệt độ CPU đang ở mức an toàn. Nếu hay bị thermal throttle, hãy kiểm tra thermal paste và luồng khí case. MIZY sẽ monitor liên tục.",
  default: "🤖 Tôi là MIZY AI! Hỏi tôi về FPS, lag, ping, nhiệt độ, hoặc để tôi tự phân tích hệ thống của bạn.",
};

function AiDots() {
  return (
    <div style={{ display: "flex", gap: 4, padding: "8px 12px" }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{
          width: 6, height: 6, borderRadius: "50%", background: COLORS.cyan,
          animation: `ai-dots 1.2s ${i * 0.2}s infinite`,
        }} />
      ))}
    </div>
  );
}

function ChatBubble({ text, isUser }) {
  return (
    <div style={{
      display: "flex", justifyContent: isUser ? "flex-end" : "flex-start",
      marginBottom: 10, animation: "fadeInUp 0.3s both",
    }}>
      {!isUser && (
        <div style={{
          width: 28, height: 28, borderRadius: "50%", flexShrink: 0,
          background: `linear-gradient(135deg,${COLORS.cyan},#006d82)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 12, marginRight: 8, boxShadow: `0 0 10px ${COLORS.cyan}66`,
          fontWeight: 700, color: COLORS.dark,
        }}>M</div>
      )}
      <div style={{
        maxWidth: "75%", padding: "8px 12px",
        borderRadius: isUser ? "12px 12px 2px 12px" : "12px 12px 12px 2px",
        background: isUser ? `linear-gradient(135deg,${COLORS.cyan}22,${COLORS.teal}22)` : COLORS.card2,
        border: `1px solid ${isUser ? COLORS.cyan + "44" : COLORS.border}`,
        fontSize: 12, lineHeight: 1.6, color: isUser ? COLORS.text : "#b0d4dd",
      }}>{text}</div>
    </div>
  );
}

export default function AIChat() {
  const [messages, setMessages] = useState([
    { text: "Xin chào! Tôi là MIZY AI 🤖 Hệ thống đã được scan. Phát hiện 4 vấn đề cần tối ưu. Bạn muốn tôi fix tự động không?", isUser: false },
  ]);
  const [input, setInput]     = useState("");
  const [typing, setTyping]   = useState(false);
  const endRef                = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, typing]);

  const send = () => {
    const txt = input.trim();
    if (!txt) return;
    setMessages((m) => [...m, { text: txt, isUser: true }]);
    setInput("");
    setTyping(true);
    const key = txt.toLowerCase();
    const resp =
      key.includes("fps")  ? AI_RESPONSES.fps  :
      key.includes("lag")  ? AI_RESPONSES.lag  :
      key.includes("ping") ? AI_RESPONSES.ping :
      key.includes("nhi")  ? AI_RESPONSES.nhiet:
      AI_RESPONSES.default;
    setTimeout(() => {
      setTyping(false);
      setMessages((m) => [...m, { text: resp, isUser: false }]);
    }, 1400);
  };

  return (
    <div className="page-enter" style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 48px)" }}>
      <SectionTitle sub="MIZY AI — trợ lý tối ưu hệ thống thông minh">
        🤖 AI <span style={{ color: COLORS.cyan }}>ASSISTANT</span>
      </SectionTitle>

      <GlowCard glow style={{ flex: 1, display: "flex", flexDirection: "column", padding: 0, overflow: "hidden" }}>
        {/* Header */}
        <div style={{
          padding: "10px 14px", borderBottom: `1px solid ${COLORS.border}`,
          display: "flex", alignItems: "center", gap: 8,
        }}>
          <div style={{
            width: 8, height: 8, borderRadius: "50%", background: "#00ff88",
            boxShadow: "0 0 8px #00ff88", animation: "blink 2s infinite",
          }} />
          <span style={{ fontSize: 11, color: COLORS.cyan, fontFamily: FONTS.display, letterSpacing: 1 }}>
            MIZY AI ONLINE
          </span>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
          {messages.map((m, i) => <ChatBubble key={i} {...m} />)}
          {typing && <AiDots />}
          <div ref={endRef} />
        </div>

        {/* Input */}
        <div style={{ padding: 12, borderTop: `1px solid ${COLORS.border}`, display: "flex", gap: 8 }}>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Hỏi về FPS, lag, ping, nhiệt độ..."
            style={{
              flex: 1, padding: "8px 12px", borderRadius: 8,
              background: "#ffffff0d", border: `1px solid ${COLORS.border}`,
              color: COLORS.text, fontFamily: FONTS.body, fontSize: 12, outline: "none",
            }}
          />
          <button onClick={send} style={{
            padding: "8px 16px", borderRadius: 8, border: "none", cursor: "pointer",
            background: `linear-gradient(90deg,${COLORS.cyan},${COLORS.teal})`,
            color: COLORS.dark, fontFamily: FONTS.display, fontSize: 11, fontWeight: 700,
            boxShadow: `0 0 12px ${COLORS.cyan}66`,
          }}>SEND</button>
        </div>
      </GlowCard>
    </div>
  );
}
