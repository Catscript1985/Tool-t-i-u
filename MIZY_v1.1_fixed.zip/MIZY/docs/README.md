# MIZY System Optimizer v1.0.0

> Tối ưu hóa PC/Laptop toàn diện — AI-powered, đa ngôn ngữ.

---

## 📁 Cấu trúc dự án

```
MIZY/
├── frontend/                   # React UI (Vite)
│   ├── src/
│   │   ├── App.jsx             # Root component
│   │   ├── main.jsx            # Entry point
│   │   ├── components/
│   │   │   ├── GlobalStyles.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   ├── UI.jsx          # GlowCard, MetricRing, StatBar, etc.
│   │   │   └── AmbientBackground.jsx
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── AIChat.jsx
│   │   │   ├── AIProfile.jsx
│   │   │   ├── AIDiagnosis.jsx
│   │   │   ├── TweaksCenter.jsx
│   │   │   ├── Benchmark.jsx
│   │   │   └── PlaceholderPage.jsx
│   │   ├── hooks/
│   │   │   └── useSystemMetrics.js
│   │   └── utils/
│   │       ├── theme.js        # Design tokens (colors, fonts)
│   │       └── tweaksData.js   # Tweak definitions
│   ├── package.json
│   └── vite.config.js
│
├── backend/
│   ├── python/                 # FastAPI REST API (port 8000)
│   │   ├── main.py             # API routes
│   │   ├── optimizer.py        # Windows tweaks engine
│   │   ├── ai_engine.py        # AI logic & diagnosis
│   │   ├── benchmarks.py       # Benchmark runner
│   │   └── requirements.txt
│   │
│   ├── cpp/                    # High-performance engine
│   │   ├── mizy_bench.cpp      # Benchmark engine (compile → mizy_bench.exe)
│   │   ├── mizy_optimizer.cpp  # Direct Windows API tweaks
│   │   └── CMakeLists.txt
│   │
│   └── java/                   # Background monitor service (port 8001)
│       ├── com/mizy/
│       │   └── MIZYMonitor.java
│       └── pom.xml
│
├── scripts/
│   ├── start.bat               # One-click launcher (Windows, run as Admin)
│   └── build_cpp.bat           # Build C++ engine
│
└── docs/
    └── README.md
```

---

## 🚀 Cài đặt và chạy

### Yêu cầu
| Tool | Version | Dùng cho |
|------|---------|----------|
| Node.js | 18+ | Frontend |
| Python | 3.10+ | Backend API |
| Java JDK | 17+ | Monitor service |
| C++ compiler | MSVC/MinGW | Benchmark engine |

### Bước 1 — Build C++ engine
```bat
scripts\build_cpp.bat
```

### Bước 2 — Build Java monitor
```bat
cd backend\java
mvn package
```

### Bước 3 — Khởi động tất cả
```bat
REM Chạy với quyền Administrator
scripts\start.bat
```

Hoặc thủ công:
```bat
# Terminal 1 — Python API
cd backend\python
pip install -r requirements.txt
uvicorn main:app --port 8000 --reload

# Terminal 2 — Java Monitor
cd backend\java
java -jar target\mizy-monitor.jar

# Terminal 3 — Frontend
cd frontend
npm install && npm run dev
```

Mở trình duyệt: **http://localhost:3000**

---

## ⚙️ Kiến trúc

```
Browser (React)
    ↕ HTTP / REST
Python FastAPI (port 8000)
    ├── psutil          → CPU, RAM, Disk metrics
    ├── subprocess      → gọi C++ engine
    ├── winreg / netsh  → Windows tweaks
    └── ai_engine.py    → diagnosis logic

C++ Engine
    ├── mizy_bench.exe      → benchmark chính xác cao
    └── mizy_optimizer.exe  → registry & WinAPI tweaks

Java Monitor (port 8001)
    ├── JMX / OperatingSystemMXBean → cross-platform metrics
    └── HTTP alerts → gửi warning về Python backend
```

---

## 🎯 Tính năng AI

| Feature | Mô tả |
|---------|-------|
| AI Chat | Phân tích câu hỏi về FPS/lag/ping, tự gợi ý tweaks |
| AI Auto-Profile | 4 profile cá nhân hóa dựa theo hardware |
| AI Diagnosis | Phát hiện vấn đề realtime với mức độ CRITICAL/WARNING |
| AI Benchmark | Giải thích kết quả bằng ngôn ngữ tự nhiên |

---

## 🔒 Lưu ý bảo mật

- Một số tweaks **cần chạy Administrator**
- Luôn có **backup registry** trước khi apply nhiều tweaks
- Tweaks có thể **revert** hoàn toàn qua `--revert` flag

---

## 📜 License

MIT © MIZY Team 2025
