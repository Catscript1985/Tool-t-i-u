# MIZY AI Architecture

## Câu hỏi: Dùng cấu trúc AI nào?

---

## ✅ Kiến trúc MIZY chọn: Rule-Based Expert System + Weighted Scoring Model

### Tại sao KHÔNG dùng Machine Learning / Neural Network?

| Tiêu chí             | ML Model     | Rule-Based (MIZY) |
|----------------------|--------------|-------------------|
| Cần training data    | Nhiều (>10k) | ❌ Không cần       |
| Cần internet         | Thường có    | ❌ Không cần       |
| Response time        | 50–500ms     | ✅ <1ms            |
| Explainable          | Khó          | ✅ Dễ debug        |
| Accuracy (domain hẹp)| 80–90%       | ✅ 90–98%          |
| Maintenance          | Phức tạp     | ✅ Đơn giản        |

---

## Sơ đồ kiến trúc

```
User Request
    │
    ▼
[HardwareDetector]          ← psutil, WMI, nvidia-smi
    │ HardwareProfile
    ▼
[PCClassifier]              ← Weighted Scoring Model
    │ LOW_END / MID / HIGH_END / LAPTOP
    ▼
[BottleneckDetector]        ← Decision Tree
    │ CPU / GPU / RAM / DISK / NET
    ▼
[TweakSelector]             ← Rule-Based Expert System
    │ Filtered + Sorted tweaks
    ▼
[HealthScorer]              ← Weighted penalty model
    │ Score 0-100, Grade S/A/B/C/D
    ▼
[SummaryGenerator]          ← Template + context
    │
    ▼
OptimizationPlan → API → Frontend
```

---

## Layer 1: Weighted Scoring Model (PC Classification)

Mỗi hardware component có weight → tổng điểm → phân loại PC class.

```python
score += cpu_cores * 5        # tối đa 30 điểm
score += 10  if freq > 4GHz
score += 20  if ram >= 32GB
score += 20  if gpu is dedicated
score += 10  if disk is NVMe

if score >= 60: HIGH_END
elif score >= 30: MID_RANGE
else: LOW_END
```

---

## Layer 2: Decision Tree (Bottleneck Detection)

```
if CPU > 85% AND GPU < 70%  → CPU bottleneck
elif GPU > 90%               → GPU bottleneck
elif RAM > 85%               → RAM bottleneck
elif disk is HDD             → DISK bottleneck
elif ping > 100ms            → NET bottleneck
else                         → NONE
```

---

## Layer 3: Rule-Based Expert System (Tweak Selection)

Rules ví dụ:

```python
IF is_intel:
    APPLY timer_resolution (priority 10)
    APPLY disable_hpet     (priority 9)

IF is_amd AND cpu_gen >= 5000:
    APPLY timer_resolution (priority 9)
    APPLY disable_hpet     (priority 7)  ← lower priority vs Intel

IF ram_total < 8GB:
    APPLY disable_superfetch (priority 9)
    APPLY page_compression_off (priority 7)

IF bottleneck == CPU:
    APPLY irq_cpu_affinity (priority 8)

IF is_laptop AND goal == BATTERY:
    APPLY power_plan_balanced  ← override vs power_plan_ultimate
```

---

## Nâng cấp lên LLM (nếu muốn)

Thêm Anthropic/OpenAI API để AI giải thích tự nhiên hơn:

```python
# ai_engine.py
import anthropic

client = anthropic.Anthropic(api_key="your-key")

def llm_explain(plan: OptimizationPlan) -> str:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=500,
        messages=[{
            "role": "user",
            "content": f"""
            Phân tích PC này và giải thích tối ưu hóa:
            CPU: {plan.hardware.cpu_name}
            GPU: {plan.hardware.gpu_name}
            Bottleneck: {plan.bottleneck}
            Health: {plan.health_score}/100
            Tweaks: {[t['id'] for t in plan.tweaks[:5]]}
            
            Trả lời bằng tiếng Việt, ngắn gọn, thân thiện.
            """
        }]
    )
    return response.content[0].text
```

---

## Tóm lại

```
Dùng ngay, offline, nhanh → Rule-Based Expert System ✅
Muốn giải thích tự nhiên  → Thêm LLM API (Claude/GPT)
Có data từ nhiều user      → Train sklearn classifier
Muốn predict hardware      → Lightweight neural net
```

MIZY v1.0 dùng Rule-Based — đủ mạnh cho 95% use cases,
không cần internet, không tốn tiền API.
