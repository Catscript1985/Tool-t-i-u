# MIZY — Master Development Prompt

Paste toàn bộ nội dung này khi muốn AI tiếp tục phát triển MIZY.

---

## CONTEXT

Bạn đang phát triển **MIZY System Optimizer** — một ứng dụng tối ưu hóa PC/Laptop
cho game thủ, viết bằng React + Python + C++ + Java.

---

## STACK HIỆN TẠI

```
Frontend  : React 18 + Vite (port 3000)
Backend   : Python FastAPI (port 8000)
Monitor   : Java service (port 8001)  
Engine    : C++17 benchmark & optimizer
AI        : Rule-Based Expert System + Weighted Scoring Model (100% local)
```

---

## CẤU TRÚC FILE

```
MIZY/
├── frontend/src/
│   ├── App.jsx                    # router chính
│   ├── components/
│   │   ├── UI.jsx                 # GlowCard, MetricRing, StatBar, Badge, CyberButton
│   │   ├── Sidebar.jsx            # nav sidebar
│   │   └── GlobalStyles.jsx       # CSS animations
│   ├── pages/
│   │   ├── Dashboard.jsx          # metrics, game mode, quick actions
│   │   ├── AIChat.jsx             # AI chat assistant
│   │   ├── AIProfile.jsx          # 4 optimization profiles
│   │   ├── AIDiagnosis.jsx        # realtime issue detection
│   │   ├── AIAnalysis.jsx         # full hardware analysis (MỚI)
│   │   ├── TweaksCenter.jsx       # 15 tweaks toggle
│   │   └── Benchmark.jsx          # benchmark + AI explanation
│   ├── hooks/useSystemMetrics.js  # live CPU/RAM/GPU polling
│   └── utils/theme.js             # COLORS, FONTS tokens
│
├── backend/python/
│   ├── main.py                    # FastAPI routes
│   ├── optimizer.py               # Windows tweaks (registry, PowerShell)
│   ├── ai_engine.py               # AI chat + diagnosis
│   ├── ai_hardware_analyzer.py    # AI hardware analysis (MỚI)
│   └── benchmarks.py             # calls C++ engine
│
├── backend/cpp/
│   ├── mizy_bench.cpp             # benchmark engine
│   └── mizy_optimizer.cpp        # direct Windows API tweaks
│
└── backend/java/
    └── MIZYMonitor.java           # background monitor + HTTP alerts
```

---

## DESIGN SYSTEM

```javascript
COLORS = {
  cyan:   "#00e5ff",   // primary accent
  teal:   "#00b4d8",   // secondary
  dark:   "#060d14",   // background
  card:   "#0a1628",   // card bg
  sidebar:"#06101a",   // sidebar bg
  border: "rgba(0,229,255,0.15)",
  green:  "#00d4aa",   // success
  gold:   "#ffd180",   // warning
  red:    "#ff6b6b",   // error/critical
  muted:  "#7aadbb",   // secondary text
}

FONTS = {
  display: "'Orbitron', monospace",  // headers, numbers
  body:    "'Exo 2', sans-serif",    // body text
}

// Key components:
<GlowCard glow={bool}>    // card with optional cyan glow
<CyberButton variant="primary|secondary">
<MetricRing value={0-100} label color size />
<StatBar label value color />
<Badge label color />
<SectionTitle sub="subtitle">Title</SectionTitle>
```

---

## AI ARCHITECTURE

```
Rule-Based Expert System + Weighted Scoring Model

Layers:
1. HardwareDetector    → đọc CPU/GPU/RAM/Disk thực tế
2. PCClassifier        → Weighted score → LOW_END/MID/HIGH_END/LAPTOP
3. BottleneckDetector  → Decision Tree → CPU/GPU/RAM/DISK/NET
4. TweakSelector       → Rule-Based → danh sách tweaks ưu tiên theo hardware
5. HealthScorer        → Weighted penalty → score 0-100
6. SummaryGenerator    → Template + context → tiếng Việt

Không cần internet. Response <1ms. 100% local.
```

---

## API ENDPOINTS

```
GET  /api/metrics              → CPU, RAM, GPU, Disk, Network realtime
GET  /api/system-info          → Hardware info
POST /api/tweak                → { tweak_id, enable }
POST /api/apply-profile        → { profile: "fps_gaming|low_latency|balanced|max_perf" }
POST /api/ai/chat              → { message, context }
GET  /api/ai/diagnose          → Full diagnosis
POST /api/ai/analyze           → { goal: "fps|latency|stability|battery|balanced" }
POST /api/benchmark/run        → Run benchmark → score
GET  /api/scan                 → Quick system scan
```

---

## TWEAKS LIST

```
timer_resolution, disable_hpet, disable_xbox_gamebar,
power_plan_ultimate, disable_superfetch, page_compression_off,
gpu_hw_scheduling, disable_nagle, network_tuner,
disable_telemetry, visual_fx_minimal, irq_cpu_affinity,
disable_fullscreen_optimizations, large_system_cache,
nvidia_max_performance
```

---

## YÊU CẦU KHI THÊM TÍNH NĂNG MỚI

1. **Frontend**: Tạo file mới trong `frontend/src/pages/` — import vào `App.jsx`
2. **Backend**: Thêm route vào `main.py` hoặc tạo file route riêng
3. **UI components**: Dùng lại GlowCard, CyberButton, Badge từ `UI.jsx`
4. **Màu**: Luôn dùng COLORS từ `theme.js` — không hardcode màu
5. **Animation**: Dùng class `page-enter` cho page transitions
6. **State**: useState cho local, không cần Redux (app đơn giản)
7. **API calls**: fetch('/api/...') — proxy qua vite.config.js sang port 8000

---

## TASK ĐÃ HOÀN THÀNH

- [x] Dashboard với live metrics (CPU/RAM/GPU ring)
- [x] Game Mode toggle
- [x] AI Chat assistant (keyword matching)
- [x] AI Auto-Profile (4 profiles)
- [x] AI Diagnosis (CRITICAL/WARNING/NORMAL)
- [x] AI Hardware Analysis (full deep analysis)
- [x] Tweaks Center (15 tweaks, toggle individual / apply all)
- [x] Benchmark (C++ engine + AI explanation)
- [x] Python FastAPI backend
- [x] C++ benchmark + optimizer engine
- [x] Java monitor service

---

## GỢI Ý TASK TIẾP THEO

- [ ] Network Optimizer page (ping test, bufferbloat, adapter settings)
- [ ] System Cleaner page (temp files, registry cleanup)
- [ ] Settings page (startup, update, language)
- [ ] Tweak history & rollback UI
- [ ] Real-time performance graph (recharts)
- [ ] Notification system (toast alerts)
- [ ] Dark/Light theme toggle
- [ ] Export report PDF
- [ ] Integrate Anthropic API cho AI chat thông minh hơn

---

## VÍ DỤ PROMPT GỬI AI

"Dựa vào MIZY project context ở trên, hãy thêm trang Network Optimizer với:
- Ping test realtime đến 3 server (Google, Cloudflare, 8.8.8.8)
- Bufferbloat grade (A/B/C/D/F) 
- Network adapter settings panel
- Dùng GlowCard, CyberButton từ UI.jsx
- Theme COLORS.cyan, COLORS.dark
- Thêm route 'network' vào App.jsx"
