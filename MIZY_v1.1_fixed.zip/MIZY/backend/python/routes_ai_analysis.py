"""
MIZY API — AI Hardware Analysis routes
Thêm vào main.py
"""
from fastapi import APIRouter
from ai_hardware_analyzer import AIHardwareAnalyzer, HardwareDetector, OptimizationGoal
from pydantic import BaseModel

router = APIRouter(prefix="/api/ai", tags=["AI Analysis"])

analyzer = AIHardwareAnalyzer()
detector = HardwareDetector()

class AnalyzeRequest(BaseModel):
    goal: str = "fps"   # fps | latency | stability | battery | balanced

@router.post("/analyze")
async def analyze_hardware(req: AnalyzeRequest):
    """
    Full AI hardware analysis → optimization plan
    """
    hw      = detector.detect()
    goal    = OptimizationGoal(req.goal) if req.goal in [g.value for g in OptimizationGoal] else OptimizationGoal.FPS
    plan    = analyzer.analyze(hw, {}, goal)

    return {
        "pc_class":       plan.pc_class.value,
        "bottleneck":     plan.bottleneck.value,
        "health_score":   plan.health_score,
        "hardware": {
            "cpu":  hw.cpu_name,
            "gpu":  hw.gpu_name,
            "ram":  f"{hw.ram_total_gb:.0f}GB",
            "disk": hw.disk_type,
        },
        "tweaks":          plan.tweaks,
        "warnings":        plan.warnings,
        "tips":            plan.tips,
        "estimated_fps":   plan.estimated_fps,
        "estimated_ping":  plan.estimated_ping,
        "ai_summary":      plan.ai_summary,
        "ai_architecture": plan.architecture,
    }
