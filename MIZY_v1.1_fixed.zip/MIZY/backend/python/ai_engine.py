"""
MIZY AI Engine
Rule-based + pattern matching diagnosis.
Có thể nâng cấp dùng OpenAI/Anthropic API thật.
"""

import re
from datetime import datetime


class MIZYAiEngine:
    """Local AI logic. No external API required."""

    # ─── Chat ─────────────────────────────────────────────────────────────────
    def respond(self, message: str, metrics: dict, context: dict) -> dict:
        msg = message.lower()
        cpu = metrics.get("cpu", {}).get("usage", 0)
        ram = metrics.get("ram", {}).get("usage_pct", 0)
        ping = metrics.get("network", {}).get("ping_ms", 0)

        # FPS issues
        if any(w in msg for w in ["fps", "giật", "lag", "frame", "drop"]):
            tweaks = ["timer_resolution", "disable_hpet", "disable_xbox_gamebar", "gpu_hw_scheduling"]
            estimate = "+18–25 FPS" if cpu < 70 else "+10–15 FPS (CPU đang cao)"
            return {
                "text": (
                    f"🎯 Phân tích xong! CPU đang ở {cpu:.0f}%. "
                    f"Gợi ý bật: Timer Resolution + HPET Disable + DPC Fix. "
                    f"Dự kiến tăng {estimate}."
                ),
                "tweaks": tweaks,
                "severity": "info",
            }

        # Network / ping
        if any(w in msg for w in ["ping", "mạng", "net", "bufferbloat", "packet"]):
            tweaks = ["disable_nagle", "network_tuner"]
            return {
                "text": (
                    f"🌐 Ping hiện tại: {ping:.0f}ms. "
                    "Apply Nagle Off + Adapter Tuner — dự kiến giảm 30–50%."
                ),
                "tweaks": tweaks,
                "severity": "info",
            }

        # RAM
        if any(w in msg for w in ["ram", "memory", "bộ nhớ", "heap"]):
            return {
                "text": (
                    f"💾 RAM đang dùng {ram:.0f}%. "
                    + ("Mức bình thường, không cần lo." if ram < 75
                       else "⚠️ Cao quá! Tắt Memory Compression và disable Superfetch ngay.")
                ),
                "tweaks": ["page_compression_off", "disable_superfetch"] if ram > 75 else [],
                "severity": "warning" if ram > 75 else "info",
            }

        # Temp / nhiệt
        if any(w in msg for w in ["nóng", "nhiệt", "temp", "thermal", "heat"]):
            return {
                "text": "🌡️ Kiểm tra thermal paste nếu CPU > 90°C liên tục. MIZY đang monitor. Đảm bảo luồng khí case tốt.",
                "tweaks": [],
                "severity": "info",
            }

        # Generic help
        return {
            "text": (
                f"🤖 Hệ thống: CPU {cpu:.0f}% · RAM {ram:.0f}% · Ping {ping:.0f}ms. "
                "Hỏi tôi về FPS, lag, ping, nhiệt độ, hoặc gõ 'scan' để tôi chạy phân tích đầy đủ!"
            ),
            "tweaks": [],
            "severity": "info",
        }

    # ─── Diagnosis ────────────────────────────────────────────────────────────
    def diagnose(self, metrics: dict) -> dict:
        issues = []
        score  = 100  # health score

        cpu   = metrics.get("cpu",     {}).get("usage",      0)
        ram   = metrics.get("ram",     {}).get("usage_pct",  0)
        ping  = metrics.get("network", {}).get("ping_ms",    0)
        gtemp = metrics.get("gpu",     {}).get("temp_c",     0)
        ctemp = metrics.get("cpu",     {}).get("temp_c",     0)

        checks = [
            (cpu  > 85, "CRITICAL", "CPU Overload",       f"CPU {cpu:.0f}% — quá cao",         -25, "timer_resolution"),
            (ram  > 85, "CRITICAL", "RAM Critical",       f"RAM {ram:.0f}% — gần đầy",          -25, "page_compression_off"),
            (ping > 80, "WARNING",  "High Latency",       f"Ping {ping:.0f}ms — không tốt",     -15, "disable_nagle"),
            (gtemp > 85,"WARNING",  "GPU Overheating",    f"GPU {gtemp:.0f}°C — quá nóng",      -15, None),
            (ctemp > 90,"CRITICAL", "CPU Overheating",    f"CPU {ctemp:.0f}°C — nguy hiểm",     -30, None),
        ]

        for condition, severity, title, desc, penalty, fix in checks:
            if condition:
                score = max(0, score + penalty)
                issues.append({
                    "title": title, "severity": severity,
                    "desc":  desc,  "fix":      fix,
                    "time":  datetime.now().strftime("%H:%M"),
                })

        if not issues:
            issues.append({
                "title": "System Healthy ✅", "severity": "NORMAL",
                "desc": "Không phát hiện vấn đề. Hệ thống đang hoạt động tốt.", "fix": None,
                "time": datetime.now().strftime("%H:%M"),
            })

        grade = "S" if score >= 90 else "A" if score >= 75 else "B" if score >= 60 else "C" if score >= 40 else "D"
        return {
            "issues":       issues,
            "health_score": score,
            "health_grade": grade,
            "timestamp":    datetime.utcnow().isoformat(),
        }

    # ─── Benchmark Analysis ───────────────────────────────────────────────────
    def analyze_benchmark(self, score: int) -> str:
        if score >= 12000:
            return f"🏆 Score {score:,} — Top 5% MIZY users. Hệ thống đã được tối ưu xuất sắc!"
        if score >= 9000:
            return (
                f"⭐ Score {score:,} — Top 35% MIZY users. "
                "CPU bottleneck nhẹ. Apply thêm Timer Resolution + HPET Disable "
                f"để đạt ~{int(score * 1.17):,}."
            )
        if score >= 6000:
            return (
                f"📊 Score {score:,} — Trung bình. "
                "Nhiều cơ hội cải thiện. Thử profile FPS Gaming "
                f"— dự kiến tăng lên ~{int(score * 1.35):,}."
            )
        return (
            f"⚠️ Score {score:,} — Thấp hơn trung bình. "
            "Hệ thống cần tối ưu nghiêm túc. Chạy AI Auto-Profile ngay!"
        )
