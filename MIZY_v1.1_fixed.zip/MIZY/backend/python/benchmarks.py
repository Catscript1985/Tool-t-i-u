"""
MIZY Benchmark Runner
Calls the C++ mizy_bench.exe engine for accurate results.
Falls back to pure-Python benchmark if .exe not found.
"""

import subprocess, time, math, os, platform
from pathlib import Path


class BenchmarkRunner:
    CPP_ENGINE = Path(__file__).parent.parent / "cpp" / "build" / "mizy_bench.exe"

    def run(self) -> int:
        if self.CPP_ENGINE.exists() and platform.system() == "Windows":
            return self._run_cpp()
        return self._run_python_fallback()

    # ── C++ engine ──────────────────────────────────────────────────────────
    def _run_cpp(self) -> int:
        try:
            result = subprocess.run(
                [str(self.CPP_ENGINE), "--score-only"],
                capture_output=True, text=True, timeout=60
            )
            return int(result.stdout.strip())
        except Exception:
            return self._run_python_fallback()

    # ── Pure-Python fallback ─────────────────────────────────────────────────
    def _run_python_fallback(self) -> int:
        scores = []
        # 1. Integer math throughput
        scores.append(self._bench_integer())
        # 2. Float / SSE simulation
        scores.append(self._bench_float())
        # 3. Memory bandwidth
        scores.append(self._bench_memory())
        return int(sum(scores) / len(scores))

    def _bench_integer(self, duration: float = 0.5) -> int:
        count = 0
        end   = time.perf_counter() + duration
        x     = 1
        while time.perf_counter() < end:
            x = (x * 6364136223846793005 + 1442695040888963407) & 0xFFFF_FFFF_FFFF_FFFF
            count += 1
        return int(count / 1000)

    def _bench_float(self, duration: float = 0.5) -> int:
        count = 0
        end   = time.perf_counter() + duration
        v     = 1.0
        while time.perf_counter() < end:
            v = math.sqrt(v * 1.000001 + 0.5)
            count += 1
        return int(count / 500)

    def _bench_memory(self, size_mb: int = 64) -> int:
        data = bytearray(size_mb * 1024 * 1024)
        start = time.perf_counter()
        # Sequential write
        for i in range(0, len(data), 4096):
            data[i] = i & 0xFF
        elapsed = time.perf_counter() - start
        mb_per_s = size_mb / max(elapsed, 0.001)
        return int(mb_per_s * 10)
