"""
MIZY System Optimizer
Applies real Windows tweaks via registry edits, PowerShell, and netsh.
Must run as Administrator for most tweaks.
"""

import subprocess, platform, socket, time
from typing import Any

IS_WINDOWS = platform.system() == "Windows"

# ─── Registry helper ─────────────────────────────────────────────────────────
def _reg_set(path: str, name: str, value: Any, reg_type: str = "REG_DWORD") -> bool:
    """Write a Windows registry value."""
    if not IS_WINDOWS:
        return False
    try:
        cmd = ["reg", "add", path, "/v", name, "/t", reg_type, "/d", str(value), "/f"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode == 0
    except Exception:
        return False

def _reg_delete(path: str, name: str) -> bool:
    if not IS_WINDOWS:
        return False
    try:
        cmd = ["reg", "delete", path, "/v", name, "/f"]
        subprocess.run(cmd, capture_output=True)
        return True
    except Exception:
        return False

def _powershell(script: str) -> tuple[bool, str]:
    """Run a PowerShell command."""
    if not IS_WINDOWS:
        return False, "Not Windows"
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=30
        )
        return result.returncode == 0, result.stdout.strip()
    except Exception as e:
        return False, str(e)

def _netsh(args: str) -> bool:
    if not IS_WINDOWS:
        return False
    try:
        result = subprocess.run(f"netsh {args}", capture_output=True, shell=True)
        return result.returncode == 0
    except Exception:
        return False

# ─── Tweak Definitions ───────────────────────────────────────────────────────
TWEAKS = {
    # ── CPU & System ──────────────────────────────────────────────────────────
    "timer_resolution": {
        "name": "Timer Resolution 0.5ms",
        "apply": lambda: _powershell(
            "bcdedit /set useplatformtick yes; bcdedit /deletevalue useplatformclock"
        )[0],
        "revert": lambda: _powershell("bcdedit /deletevalue useplatformtick")[0],
        "restart": False,
    },
    "disable_hpet": {
        "name": "Disable HPET",
        "apply": lambda: _powershell("bcdedit /set useplatformclock false")[0],
        "revert": lambda: _powershell("bcdedit /set useplatformclock true")[0],
        "restart": True,
    },
    "disable_xbox_gamebar": {
        "name": "Disable Xbox Game Bar",
        "apply": lambda: _reg_set(
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR",
            "AppCaptureEnabled", 0
        ) and _reg_set(
            r"SYSTEM\GameConfigStore", "GameDVR_Enabled", 0
        ),
        "revert": lambda: _reg_set(
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR",
            "AppCaptureEnabled", 1
        ),
        "restart": False,
    },
    "power_plan_ultimate": {
        "name": "Ultimate Performance Power Plan",
        "apply": lambda: _powershell(
            "powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61; "
            "$id=(powercfg /l | Select-String '高性能|Ultimate' | "
            "Select-Object -Last 1).Line.Split(' ')[3]; powercfg /setactive $id"
        )[0],
        "revert": lambda: _powershell("powercfg /setactive SCHEME_BALANCED")[0],
        "restart": False,
    },
    "disable_superfetch": {
        "name": "Disable SysMain (Superfetch)",
        "apply": lambda: _powershell("Stop-Service SysMain -Force; Set-Service SysMain -StartupType Disabled")[0],
        "revert": lambda: _powershell("Set-Service SysMain -StartupType Automatic; Start-Service SysMain")[0],
        "restart": False,
    },
    "page_compression_off": {
        "name": "Disable Memory Compression",
        "apply": lambda: _powershell("Disable-MMAgent -mc")[0],
        "revert": lambda: _powershell("Enable-MMAgent -mc")[0],
        "restart": False,
    },
    "gpu_hw_scheduling": {
        "name": "GPU Hardware Scheduling",
        "apply": lambda: _reg_set(
            r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers",
            "HwSchMode", 2
        ),
        "revert": lambda: _reg_set(
            r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers",
            "HwSchMode", 1
        ),
        "restart": True,
    },

    # ── Network ───────────────────────────────────────────────────────────────
    "disable_nagle": {
        "name": "Disable Nagle Algorithm",
        "apply": lambda: _reg_set(
            r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces",
            "TcpAckFrequency", 1
        ) and _reg_set(
            r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces",
            "TCPNoDelay", 1
        ),
        "revert": lambda: _reg_delete(
            r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces",
            "TcpAckFrequency"
        ),
        "restart": False,
    },
    "network_tuner": {
        "name": "Network Adapter Tuner",
        "apply": lambda: _netsh("int tcp set global autotuninglevel=highlyrestricted") and
                         _netsh("int tcp set global chimney=disabled") and
                         _netsh("int tcp set global rss=enabled"),
        "revert": lambda: _netsh("int tcp set global autotuninglevel=normal"),
        "restart": False,
    },
    "disable_telemetry": {
        "name": "Disable Telemetry",
        "apply": lambda: _reg_set(
            r"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
            "AllowTelemetry", 0
        ) and _powershell("Stop-Service DiagTrack -Force; Set-Service DiagTrack -StartupType Disabled")[0],
        "revert": lambda: _reg_set(
            r"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
            "AllowTelemetry", 1
        ),
        "restart": False,
    },
    "visual_fx_minimal": {
        "name": "Visual FX Minimal",
        "apply": lambda: _reg_set(
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects",
            "VisualFXSetting", 2
        ),
        "revert": lambda: _reg_set(
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects",
            "VisualFXSetting", 0
        ),
        "restart": False,
    },
}

# Profiles — collections of tweak_ids
PROFILES = {
    "fps_gaming": {
        "tweaks": ["timer_resolution","disable_hpet","disable_xbox_gamebar",
                   "power_plan_ultimate","disable_nagle","gpu_hw_scheduling"],
        "fps_gain": "+22 FPS avg",
    },
    "low_latency": {
        "tweaks": ["timer_resolution","disable_hpet","disable_nagle",
                   "network_tuner","disable_superfetch"],
        "fps_gain": "-18ms ping",
    },
    "balanced": {
        "tweaks": ["disable_xbox_gamebar","visual_fx_minimal","disable_telemetry",
                   "disable_superfetch"],
        "fps_gain": "+40% battery",
    },
    "max_perf": {
        "tweaks": list(TWEAKS.keys()),
        "fps_gain": "+35 FPS avg",
    },
}


# ─── SystemOptimizer class ────────────────────────────────────────────────────
class SystemOptimizer:
    def __init__(self):
        self._applied: set[str] = set()

    # GPU info via nvidia-smi or wmi
    def get_gpu_usage(self) -> float:
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=utilization.gpu",
                 "--format=csv,noheader,nounits"], timeout=3
            ).decode().strip()
            return float(out.split("\n")[0])
        except Exception:
            return 0.0

    def get_vram_used(self) -> float:
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"], timeout=3
            ).decode().strip()
            return float(out.split("\n")[0])
        except Exception:
            return 0.0

    def get_gpu_temp(self) -> float:
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=temperature.gpu",
                 "--format=csv,noheader,nounits"], timeout=3
            ).decode().strip()
            return float(out.split("\n")[0])
        except Exception:
            return 0.0

    def get_gpu_name(self) -> str:
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name",
                 "--format=csv,noheader"], timeout=3
            ).decode().strip()
            return out.split("\n")[0]
        except Exception:
            return "Unknown GPU"

    def measure_ping(self, host: str = "8.8.8.8") -> float:
        try:
            start = time.time()
            s = socket.create_connection((host, 53), timeout=2)
            s.close()
            return round((time.time() - start) * 1000, 1)
        except Exception:
            return -1.0

    def apply_tweak(self, tweak_id: str, enable: bool) -> dict:
        if tweak_id not in TWEAKS:
            return {"ok": False, "msg": f"Unknown tweak: {tweak_id}"}
        t = TWEAKS[tweak_id]
        fn = t["apply"] if enable else t["revert"]
        ok = fn()
        if ok:
            if enable: self._applied.add(tweak_id)
            else:      self._applied.discard(tweak_id)
        return {
            "ok":      ok,
            "msg":     f"{'Applied' if enable else 'Reverted'}: {t['name']}",
            "restart": t.get("restart", False),
        }

    def apply_profile(self, profile_name: str) -> dict:
        if profile_name not in PROFILES:
            return {"count": 0, "fps_gain": "N/A", "details": []}
        p = PROFILES[profile_name]
        details = []
        for tid in p["tweaks"]:
            r = self.apply_tweak(tid, True)
            details.append(r)
        return {
            "count":    len(p["tweaks"]),
            "fps_gain": p["fps_gain"],
            "details":  details,
        }

    def detect_issues(self, metrics: dict) -> list[dict]:
        issues = []
        cpu_usage = metrics.get("cpu", {}).get("usage", 0)
        ram_usage = metrics.get("ram", {}).get("usage_pct", 0)
        ping      = metrics.get("network", {}).get("ping_ms", 0)
        gpu_temp  = metrics.get("gpu", {}).get("temp_c", 0)

        if cpu_usage > 90:
            issues.append({
                "title": "CPU Overload", "severity": "CRITICAL",
                "desc":  f"CPU usage {cpu_usage}% — quá cao, có thể gây lag.",
                "fix":   "disable_superfetch",
            })
        if ram_usage > 85:
            issues.append({
                "title": "RAM Critical", "severity": "CRITICAL",
                "desc":  f"RAM sử dụng {ram_usage}% — sắp hết bộ nhớ.",
                "fix":   "page_compression_off",
            })
        if ping > 80:
            issues.append({
                "title": "High Ping", "severity": "WARNING",
                "desc":  f"Ping {ping}ms — quá cao cho gaming.",
                "fix":   "disable_nagle",
            })
        if gpu_temp > 85:
            issues.append({
                "title": "GPU Overheating", "severity": "WARNING",
                "desc":  f"GPU temp {gpu_temp}°C — nguy cơ throttle.",
                "fix":   None,
            })
        if not issues:
            issues.append({
                "title": "System Healthy", "severity": "NORMAL",
                "desc":  "Không phát hiện vấn đề nghiêm trọng.",
                "fix":   None,
            })
        return issues
