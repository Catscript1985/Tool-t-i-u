"""
MIZY Backend API Server
Python 3.10+ | FastAPI
Chạy: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import subprocess, psutil, platform, json, time
from datetime import datetime
from pydantic import BaseModel
from typing import Optional

from optimizer              import SystemOptimizer
from ai_engine              import MIZYAiEngine
from benchmarks             import BenchmarkRunner
from ai_hardware_analyzer   import AIHardwareAnalyzer, HardwareDetector, OptimizationGoal

app = FastAPI(title="MIZY API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

optimizer   = SystemOptimizer()
ai_engine   = MIZYAiEngine()
benchrunner = BenchmarkRunner()
hw_analyzer = AIHardwareAnalyzer()
hw_detector = HardwareDetector()

# ─── Models ──────────────────────────────────────────────────────────────────
class TweakRequest(BaseModel):
    tweak_id: str
    enable: bool

class ChatRequest(BaseModel):
    message: str
    context: Optional[dict] = None

class ProfileRequest(BaseModel):
    profile: str  # "fps_gaming" | "low_latency" | "balanced" | "max_perf"

# ─── Routes ──────────────────────────────────────────────────────────────────
@app.get("/api/metrics")
async def get_metrics():
    """Real-time system metrics via psutil"""
    try:
        cpu_freq = psutil.cpu_freq()
        return {
            "cpu": {
                "usage":       round(psutil.cpu_percent(interval=0.1), 1),
                "cores":       psutil.cpu_count(logical=False),
                "threads":     psutil.cpu_count(logical=True),
                "freq_mhz":    round(cpu_freq.current) if cpu_freq else 0,
                "temp_c":      _get_cpu_temp(),
            },
            "ram": {
                "usage_pct":   round(psutil.virtual_memory().percent, 1),
                "used_gb":     round(psutil.virtual_memory().used / 1e9, 1),
                "total_gb":    round(psutil.virtual_memory().total / 1e9, 1),
            },
            "gpu": {
                "usage":       optimizer.get_gpu_usage(),
                "vram_used":   optimizer.get_vram_used(),
                "temp_c":      optimizer.get_gpu_temp(),
            },
            "disk": {
                "read_mbps":   round(psutil.disk_io_counters().read_bytes / 1e6, 1) if psutil.disk_io_counters() else 0,
                "write_mbps":  round(psutil.disk_io_counters().write_bytes / 1e6, 1) if psutil.disk_io_counters() else 0,
            },
            "network": {
                "sent_mbps":   round(psutil.net_io_counters().bytes_sent / 1e6, 1),
                "recv_mbps":   round(psutil.net_io_counters().bytes_recv / 1e6, 1),
                "ping_ms":     optimizer.measure_ping(),
            },
            "timestamp": datetime.utcnow().isoformat(),
        }
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/system-info")
async def get_system_info():
    """Full system hardware info"""
    uname = platform.uname()
    return {
        "os":        f"{uname.system} {uname.release}",
        "machine":   uname.machine,
        "processor": uname.processor or platform.processor(),
        "gpu":       optimizer.get_gpu_name(),
        "ram_gb":    round(psutil.virtual_memory().total / 1e9, 1),
    }


@app.post("/api/tweak")
async def apply_tweak(req: TweakRequest):
    """Apply or revert a specific tweak"""
    result = optimizer.apply_tweak(req.tweak_id, req.enable)
    return {"success": result["ok"], "message": result["msg"], "requires_restart": result.get("restart", False)}


@app.post("/api/apply-profile")
async def apply_profile(req: ProfileRequest):
    """Apply a full AI-generated optimization profile"""
    result = optimizer.apply_profile(req.profile)
    return {"applied_tweaks": result["count"], "estimated_fps_gain": result["fps_gain"], "details": result["details"]}


@app.post("/api/ai/chat")
async def ai_chat(req: ChatRequest):
    """AI assistant endpoint"""
    metrics = await get_metrics()
    response = ai_engine.respond(req.message, metrics, req.context or {})
    return {"reply": response["text"], "suggested_tweaks": response.get("tweaks", []), "severity": response.get("severity")}


@app.get("/api/ai/diagnose")
async def ai_diagnose():
    """Full AI system diagnosis"""
    metrics = await get_metrics()
    return ai_engine.diagnose(metrics)


@app.post("/api/benchmark/run")
async def run_benchmark():
    """Run MIZY benchmark suite (calls C++ engine)"""
    score = benchrunner.run()
    ai_analysis = ai_engine.analyze_benchmark(score)
    return {"score": score, "grade": _score_grade(score), "ai_analysis": ai_analysis}


@app.get("/api/scan")
async def scan_system():
    """Deep system scan for issues"""
    metrics = await get_metrics()
    issues  = optimizer.detect_issues(metrics)
    return {"issues": issues, "issue_count": len(issues), "critical": sum(1 for i in issues if i["severity"] == "CRITICAL")}


class AnalyzeRequest(BaseModel):
    goal: str = "fps"

@app.post("/api/ai/analyze")
async def analyze_hardware(req: AnalyzeRequest):
    """Full AI hardware analysis → personalized optimization plan"""
    valid_goals = {"fps", "latency", "stability", "battery", "balanced"}
    goal = OptimizationGoal(req.goal) if req.goal in valid_goals else OptimizationGoal.FPS
    hw   = hw_detector.detect()
    metrics = {}
    try:
        metrics = (await get_metrics())
    except Exception:
        pass
    plan = hw_analyzer.analyze(hw, metrics, goal)
    return {
        "pc_class":        plan.pc_class.value,
        "bottleneck":      plan.bottleneck.value,
        "health_score":    plan.health_score,
        "hardware": {
            "cpu":  hw.cpu_name,
            "gpu":  hw.gpu_name,
            "ram":  f"{hw.ram_total_gb:.0f}GB",
            "disk": hw.disk_type,
        },
        "tweaks":          plan.tweaks,
        "warnings":        plan.warnings,
        "tips":            plan.tips,
        "estimated_fps":   plan.estimated_fps,
        "estimated_ping":  plan.estimated_ping,
        "ai_summary":      plan.ai_summary,
        "ai_architecture": plan.architecture,
    }


class AlertPayload(BaseModel):
    source:   str
    metric:   str
    value:    float
    severity: str
    metrics:  Optional[dict] = None

@app.post("/api/internal/alert")
async def internal_alert(payload: AlertPayload):
    """Receive alerts from Java monitor service"""
    # Log and store — in production write to DB or send notification
    print(f"[ALERT from {payload.source}] {payload.metric}={payload.value} ({payload.severity})")
    return {"received": True, "timestamp": datetime.utcnow().isoformat()}


# ─── Helpers ─────────────────────────────────────────────────────────────────
def _get_cpu_temp() -> float:
    try:
        temps = psutil.sensors_temperatures()
        for key in ("coretemp", "k10temp", "cpu_thermal"):
            if key in temps:
                return round(temps[key][0].current, 1)
    except Exception:
        pass
    return 0.0

def _score_grade(score: int) -> str:
    if score >= 12000: return "S"
    if score >= 9000:  return "A"
    if score >= 6000:  return "B"
    if score >= 3000:  return "C"
    return "D"


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
