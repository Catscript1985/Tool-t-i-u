"""
MIZY AI Hardware Analysis Engine
==================================
Phân tích phần cứng sâu → đưa ra kế hoạch tối ưu tuyệt đối
Dùng kiến trúc: Rule-Based Expert System + Scoring Model + Decision Tree
"""

import platform, subprocess, re
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


# ─── Enums ───────────────────────────────────────────────────────────────────
class BottleneckType(Enum):
    CPU  = "CPU"
    GPU  = "GPU"
    RAM  = "RAM"
    DISK = "DISK"
    NET  = "NETWORK"
    NONE = "NONE"

class PCClass(Enum):
    LOW_END   = "low_end"    # CPU yếu, RAM < 8GB
    MID_RANGE = "mid_range"  # Phổ thông
    HIGH_END  = "high_end"   # Gaming / workstation
    LAPTOP    = "laptop"     # Ưu tiên pin & nhiệt

class OptimizationGoal(Enum):
    FPS        = "fps"
    LATENCY    = "latency"
    STABILITY  = "stability"
    BATTERY    = "battery"
    BALANCED   = "balanced"


# ─── Data classes ─────────────────────────────────────────────────────────────
@dataclass
class HardwareProfile:
    # CPU
    cpu_name:        str   = "Unknown"
    cpu_cores:       int   = 4
    cpu_threads:     int   = 8
    cpu_freq_mhz:    float = 2000.0
    cpu_temp_c:      float = 0.0
    cpu_usage_pct:   float = 0.0
    is_intel:        bool  = False
    is_amd:          bool  = False
    is_laptop_cpu:   bool  = False   # U/H suffix
    cpu_gen:         int   = 0       # Intel gen or AMD gen estimate

    # RAM
    ram_total_gb:    float = 8.0
    ram_used_gb:     float = 4.0
    ram_usage_pct:   float = 50.0
    ram_speed_mhz:   int   = 3200
    ram_channels:    int   = 2       # dual/single channel

    # GPU
    gpu_name:        str   = "Unknown"
    gpu_usage_pct:   float = 0.0
    gpu_vram_gb:     float = 4.0
    gpu_temp_c:      float = 0.0
    is_nvidia:       bool  = False
    is_amd_gpu:      bool  = False
    is_igpu:         bool  = False   # integrated

    # Disk
    disk_type:       str   = "HDD"   # SSD / NVMe / HDD
    disk_read_mbps:  float = 100.0
    disk_write_mbps: float = 80.0

    # Network
    ping_ms:         float = 40.0
    down_mbps:       float = 50.0

    # System
    os_version:      str   = "Windows 11"
    is_laptop:       bool  = False
    battery_pct:     int   = 100
    on_battery:      bool  = False


@dataclass
class OptimizationPlan:
    pc_class:       PCClass
    bottleneck:     BottleneckType
    health_score:   int                  # 0-100
    tweaks:         list[dict]  = field(default_factory=list)
    warnings:       list[str]   = field(default_factory=list)
    tips:           list[str]   = field(default_factory=list)
    estimated_fps:  str         = ""
    estimated_ping: str         = ""
    ai_summary:     str         = ""
    architecture:   str         = ""     # AI architecture used


# ─── Hardware Detector ────────────────────────────────────────────────────────
class HardwareDetector:
    """Collects real hardware info on Windows via WMI / PowerShell / psutil"""

    def detect(self) -> HardwareProfile:
        hw = HardwareProfile()
        hw.os_version    = self._get_os()
        hw.is_laptop     = self._check_laptop()
        cpu              = self._get_cpu_info()
        hw.cpu_name      = cpu.get("name", "Unknown")
        hw.cpu_cores     = cpu.get("cores", 4)
        hw.cpu_threads   = cpu.get("threads", 8)
        hw.cpu_freq_mhz  = cpu.get("freq", 2000.0)
        hw.is_intel      = "intel" in hw.cpu_name.lower()
        hw.is_amd        = "amd"   in hw.cpu_name.lower()
        hw.is_laptop_cpu = any(s in hw.cpu_name.upper() for s in ["U", "H", "HX", "M"])
        hw.cpu_gen       = self._parse_cpu_gen(hw.cpu_name)

        ram              = self._get_ram_info()
        hw.ram_total_gb  = ram.get("total_gb", 8.0)
        hw.ram_speed_mhz = ram.get("speed", 3200)
        hw.ram_channels  = ram.get("channels", 2)

        gpu              = self._get_gpu_info()
        hw.gpu_name      = gpu.get("name", "Unknown")
        hw.gpu_vram_gb   = gpu.get("vram_gb", 4.0)
        hw.is_nvidia     = "nvidia" in hw.gpu_name.lower() or "geforce" in hw.gpu_name.lower()
        hw.is_amd_gpu    = "radeon" in hw.gpu_name.lower() or "amd"    in hw.gpu_name.lower()
        hw.is_igpu       = any(s in hw.gpu_name.lower() for s in
                               ["uhd", "iris", "radeon graphics", "vega", "760m", "780m"])

        hw.disk_type     = self._get_disk_type()
        return hw

    def _get_os(self) -> str:
        return f"{platform.system()} {platform.release()}"

    def _check_laptop(self) -> bool:
        try:
            result = subprocess.run(
                ["powershell", "-Command",
                 "(Get-WmiObject Win32_Battery) -ne $null"],
                capture_output=True, text=True, timeout=5
            )
            return "True" in result.stdout
        except Exception:
            return False

    def _get_cpu_info(self) -> dict:
        try:
            import psutil
            freq  = psutil.cpu_freq()
            name  = subprocess.check_output(
                ["powershell", "-Command",
                 "(Get-WmiObject Win32_Processor).Name"],
                timeout=5
            ).decode().strip().split("\n")[0].strip()
            return {
                "name":    name,
                "cores":   psutil.cpu_count(logical=False) or 4,
                "threads": psutil.cpu_count(logical=True)  or 8,
                "freq":    freq.max if freq else 2000.0,
            }
        except Exception:
            return {"name": platform.processor(), "cores": 4, "threads": 8, "freq": 2000.0}

    def _get_ram_info(self) -> dict:
        try:
            import psutil
            total = psutil.virtual_memory().total / 1e9
            speed_out = subprocess.check_output(
                ["powershell", "-Command",
                 "(Get-WmiObject Win32_PhysicalMemory).Speed | Select-Object -First 1"],
                timeout=5
            ).decode().strip()
            speed = int(speed_out) if speed_out.isdigit() else 3200
            return {"total_gb": total, "speed": speed, "channels": 2}
        except Exception:
            return {"total_gb": 8.0, "speed": 3200, "channels": 2}

    def _get_gpu_info(self) -> dict:
        try:
            # Try NVIDIA first
            nv = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name,memory.total",
                 "--format=csv,noheader"], timeout=5
            ).decode().strip().split(",")
            name    = nv[0].strip()
            vram_mb = int(re.sub(r"\D", "", nv[1])) if len(nv) > 1 else 4096
            return {"name": name, "vram_gb": vram_mb / 1024}
        except Exception:
            pass
        try:
            name = subprocess.check_output(
                ["powershell", "-Command",
                 "(Get-WmiObject Win32_VideoController).Name | Select-Object -First 1"],
                timeout=5
            ).decode().strip().split("\n")[0].strip()
            return {"name": name, "vram_gb": 4.0}
        except Exception:
            return {"name": "Unknown GPU", "vram_gb": 4.0}

    def _get_disk_type(self) -> str:
        try:
            out = subprocess.check_output(
                ["powershell", "-Command",
                 "(Get-PhysicalDisk | Select-Object -First 1).MediaType"],
                timeout=5
            ).decode().strip()
            if "SSD" in out:   return "SSD"
            if "NVMe" in out:  return "NVMe"
            return "HDD"
        except Exception:
            return "Unknown"

    def _parse_cpu_gen(self, name: str) -> int:
        # Intel: i5-12600K → gen 12
        m = re.search(r"i[3579]-(\d{4,5})", name)
        if m:
            return int(m.group(1)[:2])
        # AMD Ryzen: 5 5600X → gen 5xxx = zen3 ~ gen 5
        m = re.search(r"Ryzen\s+\d\s+(\d)(\d{3})", name, re.I)
        if m:
            return int(m.group(1))
        return 0


# ─── AI Analysis Engine ───────────────────────────────────────────────────────
class AIHardwareAnalyzer:
    """
    Kiến trúc AI: Rule-Based Expert System + Weighted Scoring Model

    Tại sao chọn kiến trúc này?
    ─────────────────────────────
    1. Rule-Based Expert System:
       • Không cần training data — hoạt động ngay
       • Deterministic — dễ debug, dễ audit
       • Các luật từ kiến thức chuyên gia về Windows optimization
       • Phù hợp cho domain hẹp (PC optimization) với rules rõ ràng

    2. Weighted Scoring Model:
       • Mỗi hardware component có weight khác nhau
       • Score tổng hợp → phân loại PC class → chọn tweak set
       • Dễ tuning khi có thêm data từ user feedback

    3. Decision Tree (implicit):
       • Bottleneck detection: CPU → GPU → RAM → DISK
       • Profile selection dựa theo hardware fingerprint

    Alternative đã xem xét:
    • ML model (sklearn): Cần training data, overkill cho use case này
    • LLM API (GPT/Claude): Tốt nhưng cần internet + tốn tiền
    • Neural Net: Quá phức tạp cho output là list of tweaks
    """

    def analyze(self, hw: HardwareProfile, metrics: dict,
                goal: OptimizationGoal = OptimizationGoal.FPS) -> OptimizationPlan:

        pc_class   = self._classify_pc(hw)
        bottleneck = self._detect_bottleneck(hw, metrics)
        score      = self._compute_health_score(hw, metrics)
        tweaks     = self._select_tweaks(hw, pc_class, bottleneck, goal)
        warnings   = self._generate_warnings(hw, metrics)
        tips       = self._generate_tips(hw, pc_class, bottleneck)
        fps_gain   = self._estimate_fps_gain(hw, bottleneck, tweaks)
        ping_gain  = self._estimate_ping_gain(hw, tweaks)
        summary    = self._generate_summary(hw, pc_class, bottleneck, score, goal, len(tweaks))

        return OptimizationPlan(
            pc_class       = pc_class,
            bottleneck     = bottleneck,
            health_score   = score,
            tweaks         = tweaks,
            warnings       = warnings,
            tips           = tips,
            estimated_fps  = fps_gain,
            estimated_ping = ping_gain,
            ai_summary     = summary,
            architecture   = (
                "Rule-Based Expert System + Weighted Scoring Model\n"
                "→ Không cần internet, không cần API key\n"
                "→ Chạy 100% local, deterministic, <1ms response time"
            ),
        )

    # ── 1. Classify PC ────────────────────────────────────────────────────────
    def _classify_pc(self, hw: HardwareProfile) -> PCClass:
        if hw.is_laptop:
            return PCClass.LAPTOP

        score = 0
        # CPU score
        score += min(hw.cpu_cores * 5, 30)          # max 30
        if hw.cpu_freq_mhz > 4000: score += 10
        if hw.cpu_gen >= 12:       score += 10
        # RAM score
        if hw.ram_total_gb >= 32:  score += 20
        elif hw.ram_total_gb >= 16: score += 10
        elif hw.ram_total_gb >= 8:  score += 5
        # GPU score
        if not hw.is_igpu:         score += 20
        if hw.gpu_vram_gb >= 8:    score += 10
        # Disk score
        if hw.disk_type == "NVMe": score += 10
        elif hw.disk_type == "SSD": score += 5

        if score >= 60:  return PCClass.HIGH_END
        if score >= 30:  return PCClass.MID_RANGE
        return PCClass.LOW_END

    # ── 2. Detect bottleneck ──────────────────────────────────────────────────
    def _detect_bottleneck(self, hw: HardwareProfile, metrics: dict) -> BottleneckType:
        cpu_usage = metrics.get("cpu", {}).get("usage", hw.cpu_usage_pct)
        gpu_usage = metrics.get("gpu", {}).get("usage", hw.gpu_usage_pct)
        ram_pct   = metrics.get("ram", {}).get("usage_pct", hw.ram_usage_pct)
        ping      = metrics.get("network", {}).get("ping_ms", hw.ping_ms)

        # Bottleneck detection order: CPU → GPU → RAM → NET
        if cpu_usage > 85 and gpu_usage < 70:
            return BottleneckType.CPU
        if gpu_usage > 90:
            return BottleneckType.GPU
        if ram_pct > 85:
            return BottleneckType.RAM
        if hw.disk_type == "HDD":
            return BottleneckType.DISK
        if ping > 100:
            return BottleneckType.NET
        return BottleneckType.NONE

    # ── 3. Health score (0-100) ───────────────────────────────────────────────
    def _compute_health_score(self, hw: HardwareProfile, metrics: dict) -> int:
        score = 100
        cpu_u = metrics.get("cpu", {}).get("usage", 0)
        ram_u = metrics.get("ram", {}).get("usage_pct", 0)
        ping  = metrics.get("network", {}).get("ping_ms", 40)
        gt    = metrics.get("gpu", {}).get("temp_c", 0)
        ct    = metrics.get("cpu", {}).get("temp_c", 0)

        if cpu_u > 90:   score -= 25
        elif cpu_u > 75: score -= 10
        if ram_u > 90:   score -= 25
        elif ram_u > 80: score -= 10
        if ping > 100:   score -= 15
        elif ping > 60:  score -= 5
        if gt > 90:      score -= 20
        elif gt > 80:    score -= 8
        if ct > 95:      score -= 20
        elif ct > 85:    score -= 8
        if hw.disk_type == "HDD": score -= 10
        if hw.ram_total_gb < 8:   score -= 10
        if hw.is_igpu:            score -= 5

        return max(0, score)

    # ── 4. Select tweaks based on hardware ───────────────────────────────────
    def _select_tweaks(self, hw: HardwareProfile, pc_class: PCClass,
                       bottleneck: BottleneckType,
                       goal: OptimizationGoal) -> list[dict]:
        tweaks = []

        # ── Universal tweaks (mọi PC đều nên bật) ──────────────────────────
        tweaks += [
            {"id": "disable_xbox_gamebar",  "priority": 10, "reason": "Giảm CPU overhead"},
            {"id": "disable_telemetry",     "priority": 8,  "reason": "Giảm background tasks"},
            {"id": "visual_fx_minimal",     "priority": 6,  "reason": "Giải phóng GPU/CPU nhỏ"},
        ]

        # ── CPU tweaks ─────────────────────────────────────────────────────
        if hw.is_intel:
            tweaks += [
                {"id": "timer_resolution",  "priority": 10, "reason": "Intel scheduler cần timer chính xác"},
                {"id": "disable_hpet",      "priority": 9,  "reason": "HPET gây latency trên Intel"},
            ]
        elif hw.is_amd:
            tweaks += [
                {"id": "timer_resolution",  "priority": 9,  "reason": "Cải thiện Ryzen scheduler"},
                # HPET thường tốt hơn cho AMD cũ, tệ hơn cho AMD mới
                {"id": "disable_hpet",      "priority": 7 if hw.cpu_gen >= 5000 else 3,
                 "reason": "AMD Zen3+ hoạt động tốt hơn không có HPET"},
            ]

        # ── RAM tweaks ─────────────────────────────────────────────────────
        if hw.ram_total_gb <= 8:
            tweaks += [
                {"id": "disable_superfetch", "priority": 9,
                 "reason": f"RAM chỉ {hw.ram_total_gb:.0f}GB — Superfetch lãng phí"},
                {"id": "page_compression_off", "priority": 7,
                 "reason": "Page compression tốn CPU khi RAM thấp"},
            ]
        elif hw.ram_total_gb >= 16:
            tweaks += [
                {"id": "disable_superfetch", "priority": 5,
                 "reason": "RAM đủ, Superfetch không cần thiết"},
            ]

        # ── Power plan ─────────────────────────────────────────────────────
        if not hw.is_laptop or goal == OptimizationGoal.FPS:
            tweaks.append({"id": "power_plan_ultimate", "priority": 10,
                           "reason": "Loại bỏ CPU throttling"})
        elif hw.is_laptop and goal == OptimizationGoal.BATTERY:
            tweaks.append({"id": "power_plan_balanced", "priority": 8,
                           "reason": "Laptop: tiết kiệm pin"})

        # ── GPU tweaks ─────────────────────────────────────────────────────
        if not hw.is_igpu:
            tweaks.append({"id": "gpu_hw_scheduling", "priority": 8,
                           "reason": "Dedicated GPU hỗ trợ HW scheduling"})
        if hw.is_nvidia:
            tweaks.append({"id": "nvidia_max_performance", "priority": 9,
                           "reason": "NVIDIA prefer maximum performance mode"})

        # ── Network tweaks ─────────────────────────────────────────────────
        if goal in (OptimizationGoal.FPS, OptimizationGoal.LATENCY, OptimizationGoal.BALANCED):
            tweaks += [
                {"id": "disable_nagle",  "priority": 9,  "reason": "Giảm TCP latency đáng kể"},
                {"id": "network_tuner",  "priority": 7,  "reason": "Tuner RSS & chimney"},
            ]

        # ── Bottleneck-specific extras ─────────────────────────────────────
        if bottleneck == BottleneckType.CPU:
            tweaks.append({"id": "irq_cpu_affinity", "priority": 8,
                           "reason": "CPU bottleneck: isolate IRQ to core 0"})
        if bottleneck == BottleneckType.GPU:
            tweaks.append({"id": "disable_fullscreen_optimizations", "priority": 7,
                           "reason": "GPU bottleneck: true exclusive fullscreen"})
        if bottleneck == BottleneckType.RAM:
            tweaks.append({"id": "large_system_cache", "priority": 6,
                           "reason": "RAM tight: ưu tiên cache"})

        # Sort by priority descending
        tweaks.sort(key=lambda t: -t["priority"])
        return tweaks

    # ── 5. Warnings ──────────────────────────────────────────────────────────
    def _generate_warnings(self, hw: HardwareProfile, metrics: dict) -> list[str]:
        warnings = []
        ct = metrics.get("cpu", {}).get("temp_c", 0)
        gt = metrics.get("gpu", {}).get("temp_c", 0)

        if ct > 90:
            warnings.append(f"🔴 CPU {ct}°C — NGUY HIỂM! Kiểm tra tản nhiệt ngay.")
        elif ct > 80:
            warnings.append(f"🟡 CPU {ct}°C — Cao. Xem xét reapply thermal paste.")

        if gt > 85:
            warnings.append(f"🔴 GPU {gt}°C — Quá nóng! Clean fan + thay thermal pad.")
        elif gt > 80:
            warnings.append(f"🟡 GPU {gt}°C — Hơi nóng. Đảm bảo airflow case tốt.")

        if hw.ram_total_gb < 8:
            warnings.append(f"🟡 RAM {hw.ram_total_gb:.0f}GB — Thấp. Nâng cấp lên 16GB để tăng FPS.")
        if hw.disk_type == "HDD":
            warnings.append("🟡 HDD phát hiện — Load time chậm. Nên nâng cấp SSD/NVMe.")
        if hw.is_igpu:
            warnings.append("ℹ️ iGPU — Chia sẻ RAM với CPU. FPS sẽ bị giới hạn.")
        if hw.ram_channels == 1:
            warnings.append("🟡 Single-channel RAM — Nên lắp thêm 1 thanh RAM cùng loại để dual-channel.")
        return warnings

    # ── 6. Tips ──────────────────────────────────────────────────────────────
    def _generate_tips(self, hw: HardwareProfile, pc_class: PCClass,
                       bottleneck: BottleneckType) -> list[str]:
        tips = []
        if pc_class == PCClass.LOW_END:
            tips += [
                "Giảm resolution game xuống 1080p hoặc thấp hơn",
                "Tắt anti-aliasing và ray tracing trong game settings",
                "Dùng profile Balanced thay vì Max Performance để tránh overheat",
            ]
        if pc_class == PCClass.LAPTOP:
            tips += [
                "Cắm sạc khi gaming để tránh CPU/GPU throttle",
                "Dùng laptop cooler pad để hạ nhiệt",
                "Tắt Turbo Boost nếu nhiệt độ thường xuyên > 85°C",
            ]
        if bottleneck == BottleneckType.CPU:
            tips += [
                "CPU là bottleneck chính — ưu tiên game settings giảm CPU load",
                "Tắt background apps: Chrome, Discord overlay, OBS khi gaming",
            ]
        if bottleneck == BottleneckType.GPU and not hw.is_igpu:
            tips += [
                "GPU là bottleneck — thử giảm texture quality & shadow distance",
                "Bật DLSS (NVIDIA) hoặc FSR (AMD) nếu game hỗ trợ",
            ]
        if hw.is_amd and hw.is_amd_gpu:
            tips.append("AMD CPU + AMD GPU: Bật SAM (Smart Access Memory) trong BIOS để tăng FPS")
        return tips

    # ── 7. Estimates ─────────────────────────────────────────────────────────
    def _estimate_fps_gain(self, hw: HardwareProfile, bottleneck: BottleneckType,
                           tweaks: list[dict]) -> str:
        base = 0
        high_prio = sum(1 for t in tweaks if t["priority"] >= 9)
        base += high_prio * 3

        if bottleneck == BottleneckType.CPU: base += 15
        if hw.disk_type == "HDD":           base += 5
        if hw.is_laptop:                    base = int(base * 0.7)  # laptop = less headroom
        if hw.is_igpu:                      base = int(base * 0.5)

        low  = max(3, base - 5)
        high = base + 8
        return f"+{low}–{high} FPS (ước tính)"

    def _estimate_ping_gain(self, hw: HardwareProfile, tweaks: list[dict]) -> str:
        has_nagle   = any(t["id"] == "disable_nagle"  for t in tweaks)
        has_network = any(t["id"] == "network_tuner"  for t in tweaks)
        reduction = 0
        if has_nagle:   reduction += 20
        if has_network: reduction += 10
        if reduction == 0: return "Không đổi"
        return f"−{reduction}–{reduction + 15}ms ping (ước tính)"

    # ── 8. AI Summary ─────────────────────────────────────────────────────────
    def _generate_summary(self, hw: HardwareProfile, pc_class: PCClass,
                          bottleneck: BottleneckType, score: int,
                          goal: OptimizationGoal, tweak_count: int = 0) -> str:
        grade = "S" if score >= 90 else "A" if score >= 75 else "B" if score >= 55 else "C" if score >= 35 else "D"
        cls_map = {
            PCClass.LOW_END:   "Low-end PC",
            PCClass.MID_RANGE: "Mid-range PC",
            PCClass.HIGH_END:  "High-end gaming PC",
            PCClass.LAPTOP:    "Laptop",
        }
        bneck_map = {
            BottleneckType.CPU:  f"CPU ({hw.cpu_name})",
            BottleneckType.GPU:  f"GPU ({hw.gpu_name})",
            BottleneckType.RAM:  f"RAM ({hw.ram_total_gb:.0f}GB)",
            BottleneckType.DISK: f"Storage ({hw.disk_type})",
            BottleneckType.NET:  "Network",
            BottleneckType.NONE: "không có bottleneck rõ ràng",
        }
        return (
            f"MIZY phân tích: {cls_map[pc_class]} — Health Score {score}/100 (Grade {grade}).\n"
            f"Bottleneck chính: {bneck_map[bottleneck]}.\n"
            f"Mục tiêu: {goal.value.upper()}.\n"
            f"Hệ thống: {hw.cpu_name} | {hw.ram_total_gb:.0f}GB RAM | {hw.gpu_name} | {hw.disk_type}.\n"
            f"MIZY đã chọn {tweak_count} tweaks tối ưu nhất cho cấu hình này."
        )
