/*
 * MIZY Benchmark Engine  (C++17)
 * ================================
 * Compile (Windows, MSVC):
 *   cl /O2 /EHsc /std:c++17 mizy_bench.cpp /Fe:mizy_bench.exe
 *
 * Compile (GCC / MinGW):
 *   g++ -O3 -std=c++17 -o mizy_bench.exe mizy_bench.cpp -lpsapi
 *
 * Usage:
 *   mizy_bench.exe              -- full benchmark with report
 *   mizy_bench.exe --score-only -- print score integer only (for Python)
 */

#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <cmath>
#include <numeric>
#include <algorithm>
#include <sstream>
#include <string>
#include <cstring>
#include <random>

#ifdef _WIN32
  #define WIN32_LEAN_AND_MEAN
  #include <windows.h>
  #include <psapi.h>
  #pragma comment(lib, "psapi.lib")
#endif

using Clock = std::chrono::high_resolution_clock;
using Ms    = std::chrono::duration<double, std::milli>;

// ─── Helpers ─────────────────────────────────────────────────────────────────
static double elapsed_ms(Clock::time_point start) {
    return Ms(Clock::now() - start).count();
}

static int cpu_core_count() {
    return std::max(1u, std::thread::hardware_concurrency());
}

// ─── 1. Single-thread integer throughput ─────────────────────────────────────
static long long bench_integer(double seconds = 0.8) {
    auto start = Clock::now();
    long long count = 0;
    uint64_t  x     = 0x123456789ABCDEF0ULL;
    while (elapsed_ms(start) < seconds * 1000.0) {
        // xorshift64
        x ^= x << 13; x ^= x >> 7; x ^= x << 17;
        ++count;
    }
    (void)x;  // prevent optimisation
    return count;
}

// ─── 2. Floating-point throughput (FLOPS simulation) ─────────────────────────
static long long bench_float(double seconds = 0.8) {
    auto start = Clock::now();
    long long count = 0;
    double    v     = 1.0;
    while (elapsed_ms(start) < seconds * 1000.0) {
        v = std::sqrt(v * 1.0000001 + 0.5);
        v = std::fma(v, 1.000001, 0.1);
        ++count;
    }
    (void)v;
    return count;
}

// ─── 3. Multi-thread throughput ───────────────────────────────────────────────
static long long bench_multithread(double seconds = 0.8) {
    int cores = cpu_core_count();
    std::vector<std::thread> threads;
    std::vector<long long>   results(cores, 0);

    auto worker = [&](int idx) {
        auto start = Clock::now();
        uint64_t x = 0xDEADBEEF + idx;
        long long cnt = 0;
        while (elapsed_ms(start) < seconds * 1000.0) {
            x ^= x << 13; x ^= x >> 7; x ^= x << 17;
            ++cnt;
        }
        results[idx] = cnt;
    };

    for (int i = 0; i < cores; ++i)
        threads.emplace_back(worker, i);
    for (auto& t : threads)
        t.join();

    return std::accumulate(results.begin(), results.end(), 0LL);
}

// ─── 4. Memory bandwidth ─────────────────────────────────────────────────────
static double bench_memory_mbps(size_t size_mb = 128) {
    size_t n = size_mb * 1024 * 1024;
    std::vector<uint8_t> buf(n, 0xAA);

    auto start = Clock::now();
    // Sequential write
    for (size_t i = 0; i < n; i += 64)
        buf[i] = static_cast<uint8_t>(i);
    // Sequential read
    volatile uint64_t sum = 0;
    for (size_t i = 0; i < n; i += 64)
        sum += buf[i];
    (void)sum;

    double ms = elapsed_ms(start);
    return (size_mb * 2.0) / (ms / 1000.0);  // read + write
}

// ─── 5. DPC / Timer latency (Windows only) ────────────────────────────────────
#ifdef _WIN32
static double bench_timer_latency() {
    // Measure Sleep(1) actual precision — lower = better
    const int SAMPLES = 20;
    double total = 0.0;
    for (int i = 0; i < SAMPLES; ++i) {
        auto start = Clock::now();
        Sleep(1);
        total += elapsed_ms(start);
    }
    return total / SAMPLES;
}
#else
static double bench_timer_latency() { return 1.0; }  // assume 1ms on non-Windows
#endif

// ─── Score calculation ────────────────────────────────────────────────────────
static int compute_score(long long   int_ops,
                          long long   fp_ops,
                          long long   mt_ops,
                          double      mem_mbps,
                          double      timer_ms) {
    // Normalise each sub-score to a 0-3000 range
    double s_int   = std::min(3000.0, int_ops  / 200000.0);
    double s_fp    = std::min(3000.0, fp_ops   / 100000.0);
    double s_mt    = std::min(3000.0, mt_ops   / 1000000.0);
    double s_mem   = std::min(3000.0, mem_mbps / 3.0);
    // Timer: 1ms = 3000 pts, 3ms = 1000 pts, 10ms = 300 pts
    double s_timer = std::max(300.0, 3000.0 / timer_ms);

    // Weighted average × 10
    double raw = (s_int * 0.25 + s_fp * 0.25 + s_mt * 0.25 + s_mem * 0.15 + s_timer * 0.10);
    return static_cast<int>(raw * 3.0);
}

// ─── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    bool score_only = (argc > 1 && std::string(argv[1]) == "--score-only");

    if (!score_only) {
        std::cout << "====================================\n";
        std::cout << "   MIZY Benchmark Engine v1.0\n";
        std::cout << "====================================\n";
        std::cout << "Cores detected: " << cpu_core_count() << "\n\n";
    }

    // Run all benchmarks
    if (!score_only) std::cout << "[1/5] Integer throughput... " << std::flush;
    long long int_ops = bench_integer();
    if (!score_only) std::cout << int_ops / 1000 << " Kops/s\n";

    if (!score_only) std::cout << "[2/5] FP throughput...     " << std::flush;
    long long fp_ops = bench_float();
    if (!score_only) std::cout << fp_ops / 1000 << " Kops/s\n";

    if (!score_only) std::cout << "[3/5] Multi-thread...      " << std::flush;
    long long mt_ops = bench_multithread();
    if (!score_only) std::cout << mt_ops / 1000000 << " Mops/s total\n";

    if (!score_only) std::cout << "[4/5] Memory bandwidth...  " << std::flush;
    double mem_mbps = bench_memory_mbps();
    if (!score_only) std::cout << (int)mem_mbps << " MB/s\n";

    if (!score_only) std::cout << "[5/5] Timer latency...     " << std::flush;
    double timer_ms = bench_timer_latency();
    if (!score_only) std::cout << timer_ms << " ms avg\n";

    int score = compute_score(int_ops, fp_ops, mt_ops, mem_mbps, timer_ms);

    if (score_only) {
        std::cout << score << std::endl;
        return 0;
    }

    std::cout << "\n====================================\n";
    std::cout << "  MIZY SCORE: " << score << "\n";
    std::string grade =
        score >= 12000 ? "S" : score >= 9000 ? "A" :
        score >= 6000  ? "B" : score >= 3000  ? "C" : "D";
    std::cout << "  GRADE: " << grade << "\n";
    std::cout << "====================================\n";

    return 0;
}
