/*
 * MIZY System Optimizer Core  (C++17, Windows-only)
 * ===================================================
 * Compile (MSVC, as Administrator):
 *   cl /O2 /EHsc /std:c++17 mizy_optimizer.cpp /Fe:mizy_optimizer.exe
 *       Advapi32.lib Powrprof.lib
 *
 * Usage:
 *   mizy_optimizer.exe --apply   timer_resolution
 *   mizy_optimizer.exe --revert  timer_resolution
 *   mizy_optimizer.exe --list
 *   mizy_optimizer.exe --apply-profile fps_gaming
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <powrprof.h>
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <functional>

#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "Powrprof.lib")

// ─── Registry helpers ─────────────────────────────────────────────────────────
static bool reg_set_dword(const std::wstring& path, const std::wstring& name, DWORD value) {
    HKEY hKey;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, path.c_str(), 0, NULL,
                        REG_OPTION_NON_VOLATILE, KEY_SET_VALUE, NULL, &hKey, NULL) != ERROR_SUCCESS)
        return false;
    bool ok = (RegSetValueExW(hKey, name.c_str(), 0, REG_DWORD,
                               reinterpret_cast<BYTE*>(&value), sizeof(value)) == ERROR_SUCCESS);
    RegCloseKey(hKey);
    return ok;
}

static bool reg_delete_value(const std::wstring& path, const std::wstring& name) {
    HKEY hKey;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, path.c_str(), 0, KEY_SET_VALUE, &hKey) != ERROR_SUCCESS)
        return false;
    RegDeleteValueW(hKey, name.c_str());
    RegCloseKey(hKey);
    return true;
}

// ─── Service helpers ──────────────────────────────────────────────────────────
static bool service_set_start(const std::wstring& name, DWORD startType) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_ALL_ACCESS);
    if (!scm) return false;
    SC_HANDLE svc = OpenServiceW(scm, name.c_str(), SERVICE_CHANGE_CONFIG | SERVICE_STOP);
    bool ok = false;
    if (svc) {
        ChangeServiceConfigW(svc, SERVICE_NO_CHANGE, startType,
                             SERVICE_NO_CHANGE, nullptr, nullptr, nullptr,
                             nullptr, nullptr, nullptr, nullptr);
        if (startType == SERVICE_DISABLED) {
            SERVICE_STATUS ss{};
            ControlService(svc, SERVICE_CONTROL_STOP, &ss);
        }
        CloseServiceHandle(svc);
        ok = true;
    }
    CloseServiceHandle(scm);
    return ok;
}

// ─── Power plan helper ────────────────────────────────────────────────────────
static bool set_power_plan_ultimate() {
    // Ultimate Performance GUID
    GUID guid = {0xe9a42b02, 0xd5df, 0x448d, {0xaa, 0x00, 0x03, 0xf1, 0x47, 0x49, 0xeb, 0x61}};
    // Try to enable it (may already exist)
    PowerSetActiveScheme(nullptr, &guid);
    return true;
}

// ─── Tweak definitions ────────────────────────────────────────────────────────
struct Tweak {
    std::string          name;
    std::function<bool()> apply;
    std::function<bool()> revert;
    bool                 requires_restart;
};

static std::map<std::string, Tweak> build_tweaks() {
    return {
        // ── Timer resolution ─────────────────────────────────────────────────
        { "timer_resolution", {
            "Timer Resolution 0.5ms",
            []{ return reg_set_dword(
                    L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel",
                    L"GlobalTimerResolutionRequests", 1); },
            []{ return reg_delete_value(
                    L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel",
                    L"GlobalTimerResolutionRequests"); },
            false
        }},

        // ── GPU Hardware Scheduling ──────────────────────────────────────────
        { "gpu_hw_scheduling", {
            "GPU Hardware Scheduling",
            []{ return reg_set_dword(
                    L"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers",
                    L"HwSchMode", 2); },
            []{ return reg_set_dword(
                    L"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers",
                    L"HwSchMode", 1); },
            true
        }},

        // ── Disable Xbox Game DVR ────────────────────────────────────────────
        { "disable_xbox_gamebar", {
            "Disable Xbox Game Bar",
            []{ return reg_set_dword(
                    L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR",
                    L"AppCaptureEnabled", 0)
                && reg_set_dword(L"SYSTEM\\GameConfigStore", L"GameDVR_Enabled", 0); },
            []{ return reg_set_dword(
                    L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\GameDVR",
                    L"AppCaptureEnabled", 1); },
            false
        }},

        // ── Disable Nagle ────────────────────────────────────────────────────
        { "disable_nagle", {
            "Disable Nagle Algorithm",
            []{ return reg_set_dword(
                    L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                    L"TCPNoDelay", 1)
                && reg_set_dword(
                    L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                    L"TcpAckFrequency", 1); },
            []{ return reg_delete_value(
                    L"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                    L"TCPNoDelay"); },
            false
        }},

        // ── Power plan ultimate ───────────────────────────────────────────────
        { "power_plan_ultimate", {
            "Ultimate Performance Power Plan",
            []{ return set_power_plan_ultimate(); },
            []{
                // Revert to Balanced plan
                GUID bal = {0x381b4222, 0xf694, 0x41f0,
                            {0x96, 0x85, 0xff, 0x5b, 0xb2, 0x60, 0xdf, 0x2e}};
                PowerSetActiveScheme(nullptr, &bal);
                return true;
            },
            false
        }},

        // ── Disable SysMain ───────────────────────────────────────────────────
        { "disable_superfetch", {
            "Disable SysMain (Superfetch)",
            []{ return service_set_start(L"SysMain", SERVICE_DISABLED); },
            []{ return service_set_start(L"SysMain", SERVICE_AUTO_START); },
            false
        }},

        // ── Disable Telemetry ─────────────────────────────────────────────────
        { "disable_telemetry", {
            "Disable DiagTrack Telemetry",
            []{ return reg_set_dword(
                    L"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection",
                    L"AllowTelemetry", 0)
                && service_set_start(L"DiagTrack", SERVICE_DISABLED); },
            []{ return reg_set_dword(
                    L"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection",
                    L"AllowTelemetry", 3); },
            false
        }},
    };
}

// ─── Profiles ─────────────────────────────────────────────────────────────────
static std::map<std::string, std::vector<std::string>> PROFILES = {
    { "fps_gaming",   { "timer_resolution","gpu_hw_scheduling","disable_xbox_gamebar","disable_nagle","power_plan_ultimate" }},
    { "low_latency",  { "timer_resolution","disable_nagle","disable_superfetch" }},
    { "balanced",     { "disable_xbox_gamebar","disable_telemetry","disable_superfetch" }},
    { "max_perf",     { "timer_resolution","gpu_hw_scheduling","disable_xbox_gamebar","disable_nagle","power_plan_ultimate","disable_superfetch","disable_telemetry" }},
};

// ─── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    auto tweaks = build_tweaks();

    if (argc < 2 || std::string(argv[1]) == "--list") {
        std::cout << "Available tweaks:\n";
        for (auto& [id, t] : tweaks)
            std::cout << "  " << id << "  (" << t.name << ")\n";
        std::cout << "\nProfiles: fps_gaming | low_latency | balanced | max_perf\n";
        return 0;
    }

    std::string action = argv[1];
    if (argc < 3 && action != "--list") {
        std::cerr << "Usage: mizy_optimizer.exe --apply|--revert <tweak_id>\n";
        std::cerr << "       mizy_optimizer.exe --apply-profile <profile>\n";
        return 1;
    }

    std::string target = (argc >= 3) ? argv[2] : "";

    // Apply profile
    if (action == "--apply-profile") {
        if (!PROFILES.count(target)) {
            std::cerr << "Unknown profile: " << target << "\n";
            return 1;
        }
        for (auto& tid : PROFILES[target]) {
            auto& t = tweaks[tid];
            bool ok = t.apply();
            std::cout << (ok ? "[OK] " : "[FAIL] ") << t.name << "\n";
        }
        return 0;
    }

    // Single tweak
    if (!tweaks.count(target)) {
        std::cerr << "Unknown tweak: " << target << "\n";
        return 1;
    }
    auto& t  = tweaks[target];
    bool  ok = (action == "--apply") ? t.apply() : t.revert();
    std::cout << (ok ? "[OK] " : "[FAIL] ")
              << (action == "--apply" ? "Applied" : "Reverted")
              << ": " << t.name << "\n";
    if (t.requires_restart)
        std::cout << "Note: Restart required for full effect.\n";

    return ok ? 0 : 1;
}
