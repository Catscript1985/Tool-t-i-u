package com.mizy;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import com.google.gson.Gson;

/**
 * MIZY Java Monitor Service
 * Uses standard java.lang.management API (compatible with all JDK 17+ distributions)
 */
public class MIZYMonitor {

    private static final int    PORT           = 8001;
    private static final String PYTHON_BACKEND = "http://localhost:8000";
    private static final int    POLL_INTERVAL  = 2000;

    private static final OperatingSystemMXBean OS =
        ManagementFactory.getOperatingSystemMXBean();

    private static final Gson GSON = new Gson();

    // ─── Thresholds (per-class) ──────────────────────────────────────────────
    enum Severity { NORMAL, WARNING, CRITICAL }

    record Threshold(double warn, double critical) {}

    private static final Map<String, Threshold> THRESHOLDS = Map.of(
        "cpu",  new Threshold(75.0, 90.0),
        "ram",  new Threshold(80.0, 90.0),
        "swap", new Threshold(50.0, 80.0)
    );

    // ─── Entry point ─────────────────────────────────────────────────────────
    public static void main(String[] args) throws Exception {
        System.out.println("MIZY Monitor Service starting on port " + PORT + "...");

        // Background polling thread
        ScheduledExecutorService pool = Executors.newScheduledThreadPool(2);
        pool.scheduleAtFixedRate(MIZYMonitor::pollAndAlert, 0, POLL_INTERVAL, TimeUnit.MILLISECONDS);

        // HTTP server
        try (ServerSocket server = new ServerSocket(PORT)) {
            server.setReuseAddress(true);
            System.out.println("MIZY Monitor ready.");
            while (!Thread.currentThread().isInterrupted()) {
                Socket client = server.accept();
                pool.submit(() -> handleRequest(client));
            }
        }
    }

    // ─── Metrics collection ───────────────────────────────────────────────────
    static SystemMetrics collect() {
        SystemMetrics m = new SystemMetrics();
        // systemCpuLoad is available on standard OperatingSystemMXBean in JDK 17+
        double cpuLoad = OS.getSystemLoadAverage();
        m.cpu_usage  = cpuLoad >= 0 ? Math.min(cpuLoad * 10, 100.0) : 0.0;
        m.cpu_cores  = OS.getAvailableProcessors();

        Runtime rt   = Runtime.getRuntime();
        long usedMem = rt.totalMemory() - rt.freeMemory();
        long maxMem  = rt.maxMemory();
        m.ram_total_gb   = maxMem  / 1e9;
        m.ram_used_gb    = usedMem / 1e9;
        m.ram_usage_pct  = maxMem > 0 ? (double) usedMem / maxMem * 100.0 : 0;

        m.jvm_heap_mb    = rt.totalMemory() / (1024 * 1024);
        m.jvm_heap_max   = rt.maxMemory()   / (1024 * 1024);
        m.jvm_threads    = Thread.activeCount();
        m.timestamp      = System.currentTimeMillis();
        return m;
    }

    // ─── Alert logic ─────────────────────────────────────────────────────────
    static void pollAndAlert() {
        SystemMetrics m = collect();
        checkThreshold("cpu", m.cpu_usage, m);
        checkThreshold("ram", m.ram_usage_pct, m);
    }

    static void checkThreshold(String metric, double value, SystemMetrics ctx) {
        Threshold t = THRESHOLDS.get(metric);
        if (t == null) return;
        Severity s = value >= t.critical() ? Severity.CRITICAL
                   : value >= t.warn()     ? Severity.WARNING
                   : Severity.NORMAL;
        if (s != Severity.NORMAL) {
            sendAlert(metric, value, s, ctx);
        }
    }

    static void sendAlert(String metric, double value, Severity severity, SystemMetrics ctx) {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("source",   "java_monitor");
            body.put("metric",   metric);
            body.put("value",    value);
            body.put("severity", severity.name());
            body.put("metrics",  ctx);

            HttpURLConnection conn = (HttpURLConnection)
                new URL(PYTHON_BACKEND + "/api/internal/alert").openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(1000);
            conn.setReadTimeout(1000);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(GSON.toJson(body).getBytes());
            }
            conn.disconnect();
        } catch (Exception e) {
            // Backend not available — silently skip
        }
    }

    // ─── HTTP handler ─────────────────────────────────────────────────────────
    static void handleRequest(Socket client) {
        try (client;
             BufferedReader in  = new BufferedReader(new InputStreamReader(client.getInputStream()));
             OutputStream   out = client.getOutputStream()) {

            // Read request line
            String line = in.readLine();
            if (line == null) return;

            String path  = line.split(" ").length > 1 ? line.split(" ")[1] : "/";
            String body  = "";
            int    status = 200;

            switch (path) {
                case "/metrics" -> body = GSON.toJson(collect());
                case "/health"  -> body = "{\"status\":\"ok\",\"service\":\"mizy-monitor\"}";
                case "/threads" -> body = GSON.toJson(threadDump());
                default         -> { body = "{\"error\":\"not found\"}"; status = 404; }
            }

            String response = "HTTP/1.1 " + status + " OK\r\n"
                + "Content-Type: application/json\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Content-Length: " + body.length() + "\r\n\r\n"
                + body;

            out.write(response.getBytes());
        } catch (Exception e) {
            // ignore connection errors
        }
    }

    static Map<String, Object> threadDump() {
        Map<String, Object> dump = new LinkedHashMap<>();
        dump.put("active_threads", Thread.activeCount());
        List<String> names = new ArrayList<>();
        Thread.getAllStackTraces().keySet().forEach(t -> names.add(t.getName()));
        dump.put("threads", names);
        return dump;
    }

    // ─── Data class ───────────────────────────────────────────────────────────
    static class SystemMetrics {
        double cpu_usage;
        int    cpu_cores;
        double ram_total_gb;
        double ram_used_gb;
        double ram_usage_pct;
        long   jvm_heap_mb;
        long   jvm_heap_max;
        int    jvm_threads;
        long   timestamp;
    }
}
