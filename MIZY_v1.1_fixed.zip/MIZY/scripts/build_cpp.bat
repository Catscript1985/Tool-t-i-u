@echo off
title MIZY C++ Build
echo Building MIZY C++ Engine...

cd /d "%~dp0..\backend\cpp"
mkdir build 2>nul
cd build

REM Try CMake first
where cmake >nul 2>&1
if %errorLevel% EQU 0 (
    cmake .. -G "Visual Studio 17 2022" -A x64
    cmake --build . --config Release
    echo.
    echo [OK] Built with CMake. Binaries in backend\cpp\build\
    goto :done
)

REM Fallback: direct MSVC
where cl >nul 2>&1
if %errorLevel% EQU 0 (
    cl /O2 /EHsc /std:c++17 ..\mizy_bench.cpp     /Fe:mizy_bench.exe
    cl /O2 /EHsc /std:c++17 ..\mizy_optimizer.cpp /Fe:mizy_optimizer.exe Advapi32.lib Powrprof.lib
    echo [OK] Built with MSVC.
    goto :done
)

REM Fallback: MinGW g++
where g++ >nul 2>&1
if %errorLevel% EQU 0 (
    g++ -O3 -std=c++17 -o mizy_bench.exe     ..\mizy_bench.cpp     -lpsapi
    g++ -O3 -std=c++17 -o mizy_optimizer.exe ..\mizy_optimizer.cpp -ladvapi32 -lpowrprof
    echo [OK] Built with MinGW.
    goto :done
)

echo [ERROR] No C++ compiler found. Install Visual Studio or MinGW.

:done
cd /d "%~dp0"
pause
