@echo off
title MIZY System Optimizer
color 0B
echo.
echo  ================================================
echo    MIZY SYSTEM OPTIMIZER  v1.0.0
echo  ================================================
echo.

REM ── Check Administrator ─────────────────────────────────────────────────────
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo [ERROR] Run as Administrator for full functionality.
    echo.
    pause
    exit /b 1
)

REM ── Start Python backend ────────────────────────────────────────────────────
echo [1/3] Starting Python API server...
cd /d "%~dp0backend\python"
if not exist venv (
    echo     Creating Python venv...
    python -m venv venv
    call venv\Scripts\activate.bat
    pip install -r requirements.txt -q
) else (
    call venv\Scripts\activate.bat
)
start /min "MIZY API" cmd /c uvicorn main:app --host 127.0.0.1 --port 8000
timeout /t 2 >nul

REM ── Start Java monitor ──────────────────────────────────────────────────────
echo [2/3] Starting Java Monitor Service...
cd /d "%~dp0backend\java"
if exist target\mizy-monitor.jar (
    start /min "MIZY Monitor" cmd /c java -jar target\mizy-monitor.jar
) else (
    echo     [SKIP] mizy-monitor.jar not found. Run: mvn package
)
timeout /t 1 >nul

REM ── Launch frontend ─────────────────────────────────────────────────────────
echo [3/3] Launching MIZY UI...
cd /d "%~dp0frontend"
if not exist node_modules (
    echo     Installing npm packages...
    npm install -q
)
start "" npm run dev
timeout /t 3 >nul

REM ── Open browser ────────────────────────────────────────────────────────────
start "" http://localhost:3000

echo.
echo  [OK] MIZY is running!
echo       UI      : http://localhost:3000
echo       API     : http://localhost:8000/docs
echo       Monitor : http://localhost:8001/metrics
echo.
echo  Press any key to stop all services...
pause >nul

REM ── Shutdown ─────────────────────────────────────────────────────────────────
echo Stopping services...
taskkill /f /fi "WINDOWTITLE eq MIZY API"     >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq MIZY Monitor" >nul 2>&1
taskkill /f /im node.exe                      >nul 2>&1
echo Done. Goodbye!
